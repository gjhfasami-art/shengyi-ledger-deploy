# 盛亿车辆出入库联动台账（网站版）部署说明

> 目标：把网站版台账部署到深圳阿里云 ECS 上，域名是 `taizhang.shengyilianhe.com`。
> 全程只需要用户在阿里云 Workbench 网页终端里粘贴运行一条命令，不用自己敲一堆命令。
> 部署脚本在同目录的 `deploy.sh`，先看完这份说明再动手。

## 总体流程（先看懂再动手）

一共四步，按顺序走：

1. **域名解析**：给 `taizhang.shengyilianhe.com` 加一条 A 记录，指向 ECS 公网 IP `47.119.191.177`。
2. **跑一键脚本**：在 Workbench 里以 root 身份粘贴运行一条命令，脚本自动装环境、拉代码、起服务、配 nginx、申请证书。
3. **并行试运行**：网站跑起来之后，先跟老 Excel **并排用**。老 Excel 继续当正在用的系统，照常用；网站这边销售按纸质合同录入，两边互不关联、互不影响，不要急着切过去。
4. **切换**：试运行没问题、数据录得差不多了，切换那天再拿**当时最新的 Excel** 跟网站核对一遍，把中间新记的东西补上，核对无误再切过去。切过去之后，老 Excel 留档备查。

> 注意：不要一部署完就停用 Excel。切换是最后一步，以切换那天的最新 Excel 为准——老表还会继续变，现在这份 Excel 到切换那天可能已经不一样了。

---

## 前置条件（动手前先确认这几样都有）

| 条件 | 说明 |
|---|---|
| 深圳阿里云 ECS | 就是现在跑企微回调的那台深圳 ECS，公网 IP 是 `47.119.191.177` |
| 域名已备案 | 主域名 `shengyilianhe.com` 已备案，备案号：闽ICP备2024042131号-4。**子域名 `taizhang.shengyilianhe.com` 不用单独备案**，直接用 |
| 安全组放行 80 和 443 端口 | 见下面“安全组”一节，没放行的话网站打不开、证书也申请不了 |
| Workbench 能登录 | 阿里云 ECS 控制台里的 Workbench 网页终端，用 root 身份登录 |
| 两个下载链接 | 主 agent 提供：① `deploy.sh` 的下载链接；② 代码 zip 的下载链接（主 agent 把 `~/workspace/ledger-web` 打成 zip 上传后给的） |

### 安全组：放行 80 和 443 端口

在部署之前先做一次，以后不用再做：

1. 打开阿里云控制台，点左侧“云服务器 ECS”，进“实例”列表。
2. 找到深圳那台 ECS，点它的实例名进详情页。
3. 在详情页找到“安全组”那一行，点安全组的名字，进安全组详情。
4. 点“入方向”那一栏，点“手动添加”或“添加规则”。
5. 加两条规则：一条端口范围填 `80/80`，授权对象填 `0.0.0.0/0`；再一条端口范围填 `443/443`，授权对象填 `0.0.0.0/0`。协议都是 TCP，点保存。
6. 回到入方向列表，确认能看到 80 和 443 两条规则。

> 如果安全组里已经有放行 80/443 的规则，就不用重复加。

---

## 第一步：域名解析（加 A 记录）

1. 打开阿里云控制台，点左侧“域名与网站”，再点“域名”，进域名列表。
2. 在列表里找到 `shengyilianhe.com`，点它右边的“解析设置”（有的版本显示为“解析”），进解析记录列表。
3. 点“添加记录”，按下面填：
   - **记录类型**：选 `A`
   - **主机记录**：填 `taizhang`
   - **解析线路**：默认（一般是“默认”）
   - **记录值**：填 `47.119.191.177`
   - **TTL**：默认（一般是 10 分钟）
4. 点“确定”保存。列表里多了一条 `taizhang.shengyilianhe.com` → `47.119.191.177` 就是成功了。

### 怎么确认解析生效了

在自己电脑上打开命令行（Windows 按 Win+R 输入 `cmd` 回车；Mac 打开“终端”），输入：

```
ping taizhang.shengyilianhe.com
```

看到返回的 IP 是 `47.119.191.177`，就是生效了。刚加完一般几分钟生效，最长可能要几十分钟；如果 ping 出来的还是别的 IP 或解析不到，就等一会儿再试。**解析没生效之前不要跑部署脚本**，否则证书那一步会失败（网站本身能先跑起来，但 https 要等解析生效后手动再申请，见“常见问题”）。

---

## 第二步：代码怎么打包上传（这一步是主 agent 做的，用户不用动手）

主 agent 把 `~/workspace/ledger-web` 整个目录打成一个 zip（zip 里就是 `ledger-web` 的内容，`app.py` 在最外层），上传后会给两个下载链接：

- ① `deploy.sh` 的下载链接（部署脚本本身）
- ② 代码 zip 的下载链接（跑脚本时要作为 `CODE_URL` 传进去）

用户拿到这两个链接之后，再做第三步。如果链接打不开或过期了，找主 agent 重新给。

---

## 第三步：在 Workbench 里运行一键脚本（就一条命令）

1. 打开阿里云控制台，点左侧“云服务器 ECS”，进“实例”列表。
2. 找到深圳那台 ECS，在它那一行点“远程连接”，选“Workbench 远程连接”。
3. 在弹出的登录框里选 root 身份登录（用户名填 `root`），点登录，进到网页终端（黑底的命令行窗口）。
4. 把下面这条命令**整条复制**，粘贴到 Workbench 终端里，回车运行。注意把两个尖括号里的内容换成主 agent 给的真实链接，尖括号本身不要留着：

```bash
curl -fsSL -o /tmp/deploy.sh "<deploy.sh 的下载链接>" && CODE_URL="<代码 zip 的下载链接>" bash /tmp/deploy.sh
```

举个例子（链接是假的，只看格式）：

```bash
curl -fsSL -o /tmp/deploy.sh "https://example.com/files/deploy.sh" && CODE_URL="https://example.com/files/ledger-web.zip" bash /tmp/deploy.sh
```

5. 脚本会一步一步打印中文进度，一共 8 步：装环境 → 下载代码 → 确认代码结构 → 同步代码 → 装 Python 依赖 → 起 systemd 服务 → 配 nginx → 申请证书。跑完大概几分钟，中间不用管它。
6. 跑完最后会打印“部署完成”，下面有服务状态和访问地址。看到 `https://taizhang.shengyilianhe.com` 就是成功了。

### 脚本每一步在干什么（不用背，出问题时对照着看）

| 步骤 | 做的事 |
|---|---|
| 1/8 | 装 python3、pip、venv、nginx、certbot、unzip、curl、rsync（Ubuntu 用 apt 装，Alibaba Cloud Linux/CentOS 用 dnf 或 yum 装，脚本自己判断） |
| 2/8 | 从 `CODE_URL` 下载代码 zip；如果 `/opt/ledger-web/ledger.db` 已经存在，先备份一份到 `/root/ledger-db-backup/` |
| 3/8 | 解压并确认 zip 里有 `app.py` 和 `requirements.txt`（zip 里多包一层文件夹也能自动找到） |
| 4/8 | 把代码同步到 `/opt/ledger-web`；数据库 `ledger.db` 和虚拟环境 `venv` 不动 |
| 5/8 | 建虚拟环境（已有就不再建），`pip install -r requirements.txt` 装依赖（只有 Flask） |
| 6/8 | 写 systemd 服务文件 `ledger-web`，`enable` + `restart`，确认服务在跑 |
| 7/8 | 写 nginx 配置反代到 `127.0.0.1:5000`，`nginx -t` 检查通过后 reload |
| 8/8 | 用 certbot 给 `taizhang.shengyilianhe.com` 申请 Let's Encrypt 免费证书，并配成 http 自动跳 https |

### 脚本可以重复跑

更新代码时，主 agent 重新打包上传、给一个新的代码 zip 链接，用户再跑一次第三步那条命令就行。重跑时脚本会：先备份数据库，再同步新代码，再重启服务。**数据库不会丢**，但为保险起见，更新前还是按“备份方法”那一节手动再备一份。

> 提醒：更新时也要从 `/tmp/deploy.sh` 跑（就是第三步那条命令），不要直接跑 `/opt/ledger-web/deploy.sh`——脚本同步代码时会覆盖它自己，从 `/tmp` 跑才安全。

---

## 第四步：验证（部署完马上做）

### 1. 浏览器验证

在浏览器地址栏输入：

```
https://taizhang.shengyilianhe.com
```

看到登录页，就是成功了。如果证书那一步失败了，脚本最后会说 https 暂未开通，那就先打开：

```
http://taizhang.shengyilianhe.com
```

能看到登录页也算部署成功，证书按“常见问题 → 证书失败”手动补申请。

### 2. 命令行验证（在 Workbench 里跑）

```bash
systemctl status ledger-web --no-pager -l
curl -s -o /dev/null -w "本机后端返回 HTTP %{http_code}\n" http://127.0.0.1:5000/
curl -I https://taizhang.shengyilianhe.com
```

- `systemctl status` 里看到 `active (running)` 就是服务在跑。
- `curl` 本机后端返回 `200` 就是后端正常。
- `curl -I https://...` 返回 `HTTP/2 200` 或 `HTTP/1.1 200` 就是整条链路通了。

---

## 并行试运行（部署成功后，不要马上切换）

1. **老 Excel 继续当正在用的系统**，照常记、照常改，不要停。
2. **网站这边销售按纸质合同录入**，一份合同一份合同地录（具体做法见同目录的《销售录入清单》）。录入的数据源是纸质合同，骨架一好就可以开始录。
3. **两边同步走、互不关联、互不影响**：网站里录了什么，不会改到 Excel；Excel 里改了什么，也不会同步到网站。这是特意这样定的，试运行期间两边各记各的。
4. 试运行期间每天抽空对照一下：网站里录的跟纸质合同对不对得上，有没有录错、漏录。发现网站有 bug，先记下来找主 agent 修，Excel 那边不受影响。
5. 试运行多久由老板定，觉得稳了再走下面的“切换”。

---

## 切换（最后一步）

切换那天按这个顺序做，不要跳步：

1. 先把老 Excel 从 WPS 云盘上下载下来**当时最新的一份**（以这份为准，老表还会继续变，不要拿几天前的旧文件来核对）。
2. 一条一条跟网站核对：车辆 26 辆、司机 46 名、出库 35 条、收车 11 条，车牌、司机、月租、押金、日期、模式有没有对不上的。
3. 把核对发现的差距补上：Excel 里有、网站里没有的，按《销售录入清单》补录进网站；网站里录错的，改过来。
4. 核对无误、双方都确认之后，再切过去：从这天起以网站为准，老 Excel 停止更新，留档备查。
5. 切换后第一周每天看一眼网站数据，发现不对马上说，不要等攒多了再查。

---

## 更新流程（网站代码改了之后）

1. 主 agent 重新打包上传代码 zip，给一个新的下载链接。
2. 用户按“备份方法”手动备份一次数据库（求稳）。
3. 在 Workbench 里再跑一次第三步那条命令（把 `CODE_URL` 换成新的链接）。
4. 跑完按“第四步：验证”检查一遍，打开网站确认登录页正常、数据还在。
5. 脚本重跑时会自动备份数据库到 `/root/ledger-db-backup/`，但手动备份还是建议做，双保险。

---

## 备份方法（数据库只有一个文件，很重要）

数据库就是 `/opt/ledger-web/ledger.db` 这一个文件，备份就是把它复制一份。

### 手动备份（更新代码、切换之前都要做一次）

在 Workbench 里跑：

```bash
mkdir -p /root/ledger-db-backup
cp /opt/ledger-web/ledger.db /root/ledger-db-backup/ledger-$(date +%Y%m%d-%H%M%S).db
ls -l /root/ledger-db-backup/
```

看到新复制出来的文件、大小不是 0，就是备好了。

### 定时自动备份（推荐加上，每天凌晨备一份）

在 Workbench 里跑 `crontab -e`，在文件最后加一行（每天凌晨 3 点备份，保留最近 30 天的）：

```
0 3 * * * mkdir -p /root/ledger-db-backup && cp /opt/ledger-web/ledger.db /root/ledger-db-backup/ledger-$(date +\%Y\%m\%d-\%H\%M\%S).db && find /root/ledger-db-backup -name 'ledger-*.db' -mtime +30 -delete
```

加完保存退出。第二天早上看一眼 `/root/ledger-db-backup/` 里有没有新文件，有就是定时备份在跑了。

### 恢复（万一数据库坏了或丢了）

```bash
systemctl stop ledger-web
cp /root/ledger-db-backup/ledger-YYYYMMDD-HHMMSS.db /opt/ledger-web/ledger.db
systemctl start ledger-web
systemctl status ledger-web --no-pager -l
```

把 `ledger-YYYYMMDD-HHMMSS.db` 换成实际要恢复的那个备份文件名。恢复完打开网站确认数据回来了。

---

## 证书续期

- Let's Encrypt 证书有效期 90 天，certbot 装好之后会自动续（系统里有 certbot 的定时任务，到期前 30 天内自动续，不用人工操作）。
- 检查自动续期有没有在跑：

```bash
systemctl list-timers | grep certbot
certbot renew --dry-run
```

第一条能看到 certbot 的定时任务，第二条最后显示成功，就是没问题。`--dry-run` 是演练，不会真的换证书，放心跑。

- 提醒时间：**每两个月检查一次**，跑上面两条命令看一眼就行；也可以在日历上记一下，下次检查定在 2027 年 1 月中旬（证书是 2026 年 11 月申请的，90 天后到期，也就是 2027 年 2 月前后到期，提前检查最稳妥）。
- 如果自动续期失败了，手动跑一次：

```bash
certbot renew
systemctl reload nginx
```

---

## 常见问题

### 1. 脚本一跑就停，提示没有 CODE_URL

原因：命令里没写 `CODE_URL="..."`，或者链接两边的引号没配对。
办法：把第三步那条命令整条重新复制一遍，确认 `CODE_URL="<代码 zip 的下载链接>"` 写对了，尖括号不要留着。

### 2. 脚本提示必须用 root 运行

原因：Workbench 登录时选的不是 root。
办法：退出 Workbench，重新登录，用户名填 `root` 再跑。

### 3. 代码 zip 下载失败

原因：`CODE_URL` 链接错了、过期了，或者 ECS 当时上不了网。
办法：先在 Workbench 里跑 `curl -I "<代码 zip 的下载链接>"` 看看能不能通；不通就找主 agent 重新给一个链接。

### 4. 服务起不来（`systemctl status ledger-web` 不是 running）

先看日志，日志会直接说原因：

```bash
journalctl -u ledger-web -n 100 --no-pager
```

- 日志里有 Python 报错（比如 `ModuleNotFoundError`、`SyntaxError`）：一般是代码或依赖的问题，截图发给主 agent。
- 日志里有 `Address already in use`：5000 端口被别的程序占了。查是谁占的：

```bash
ss -tlnp | grep 5000
```

  找到占用的进程，停掉它（如果占用的是之前跑起来的旧 ledger-web，直接 `systemctl restart ledger-web` 就行）。

### 5. 打开网站显示 502 Bad Gateway

意思是 nginx 在跑，但后端没接上。按顺序查：

```bash
systemctl status ledger-web --no-pager -l
journalctl -u ledger-web -n 50 --no-pager
tail -n 50 /var/log/nginx/error.log
```

- 服务没在跑：按问题 4 处理，`systemctl restart ledger-web` 再试。
- 服务在跑但 nginx 日志里有 `connect() failed (111: Connection refused)`：后端监听地址不对，确认 app.py 是监听 `0.0.0.0:5000`（骨架就是这么定的），不是 `127.0.0.1` 以外的地址。

### 6. 证书失败（脚本最后说 https 暂未开通）

网站先用 http 跑着，功能不受影响。按顺序排查：

1. 域名解析生效了没有：`ping taizhang.shengyilianhe.com`，返回的 IP 必须是 `47.119.191.177`。没生效就等生效后再申请。
2. 安全组放行 80 和 443 端口了没有：按“前置条件 → 安全组”检查一遍。
3. 80 端口有没有被别的程序占：`ss -tlnp | grep ':80'`。
4. 都没问题后，在 Workbench 里手动再申请一次：

```bash
certbot --nginx -d taizhang.shengyilianhe.com --non-interactive --agree-tos --register-unsafely-without-email --redirect
nginx -t && systemctl reload nginx
```

5. 如果提示申请次数超限（Let's Encrypt 每周每个域名最多 5 次失败），等一小时后再试，不要连续反复跑。

### 7. nginx -t 报错

先看报错信息指出的那一行是哪个文件、哪一行。最常见的是配置文件手改改错了。如果是脚本刚写好的配置就报错，把报错信息完整截图发给主 agent，不要自己猜着改。

### 8. 浏览器打开是 nginx 默认欢迎页，不是登录页

说明 nginx 在跑，但 `taizhang.shengyilianhe.com` 这个站点的配置没生效。检查：

```bash
ls -l /etc/nginx/conf.d/
nginx -t
cat /etc/nginx/conf.d/ledger-web.conf
```

确认 `ledger-web.conf` 存在、里面 `server_name` 是 `taizhang.shengyilianhe.com`，然后 `systemctl reload nginx` 再刷新浏览器。

---

## 回滚（部署搞砸了，想退回上一步）

1. 停服务：`systemctl stop ledger-web`
2. 恢复数据库（按“备份方法 → 恢复”）：把最近的一份备份拷回 `/opt/ledger-web/ledger.db`
3. 如果是代码更新后出问题，让主 agent 重新打一份上一个能跑的代码 zip，再跑一次部署脚本
4. 起服务：`systemctl start ledger-web`，按“第四步：验证”检查

---

## 附：关键信息一览

| 项目 | 内容 |
|---|---|
| 网站地址 | `https://taizhang.shengyilianhe.com`（证书没好之前先用 `http://taizhang.shengyilianhe.com`） |
| ECS 公网 IP | `47.119.191.177` |
| 代码目录 | `/opt/ledger-web` |
| 入口 | `app.py`，`python3 app.py` 启动，监听 `0.0.0.0:5000` |
| 数据库 | `/opt/ledger-web/ledger.db`（SQLite，备份就是拷这个文件） |
| systemd 服务 | `ledger-web`，看日志：`journalctl -u ledger-web` |
| nginx 配置 | `/etc/nginx/conf.d/ledger-web.conf`，反代到 `127.0.0.1:5000` |
| 部署脚本 | 同目录 `deploy.sh` |
| 备案号 | 闽ICP备2024042131号-4（主域名已备，子域名不用单独备案） |
