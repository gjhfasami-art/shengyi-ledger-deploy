#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 12 辆自营车 + 司机 + 出库导入台账网站数据库。
在服务器 Workbench 里跑（先部署好新代码、服务重启后再跑）：
    cd /opt/ledger-web
    cp ledger.db ledger.db.bak-import-$(date +%Y%m%d-%H%M%S)   # 先备份（脚本也会自动再备一份）
    /opt/ledger-web/venv/bin/python import_self_owned.py
也可以指定库和数据文件：
    /opt/ledger-web/venv/bin/python import_self_owned.py --db /opt/ledger-web/ledger.db --data import_self_owned.json
幂等：按车牌 / 司机编号 / 出库编号去重，已存在的跳过不重复插。
绝不碰 users 表，不改任何账号密码。
"""
import argparse
import json
import os
import shutil
import sqlite3
import sys
from datetime import datetime

DEFAULT_DB = "/opt/ledger-web/ledger.db"


def ensure_status_column(db):
    cols = [r[1] for r in db.execute("PRAGMA table_info(vehicles)")]
    if "status" not in cols:
        db.execute(
            "ALTER TABLE vehicles ADD COLUMN status TEXT NOT NULL DEFAULT '正常'")
        print("已补加 vehicles.status 列（老库没有这列）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=DEFAULT_DB,
                    help="数据库路径，默认 /opt/ledger-web/ledger.db")
    ap.add_argument("--data", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "import_self_owned.json"),
        help="数据文件，默认同目录下的 import_self_owned.json")
    args = ap.parse_args()

    if not os.path.exists(args.data):
        print("找不到数据文件: %s" % args.data)
        return 1
    if not os.path.exists(args.db):
        print("找不到数据库: %s" % args.db)
        return 1
    with open(args.data, encoding="utf-8") as f:
        data = json.load(f)

    # 先备份数据库，万一导错了能恢复
    bak = "%s.bak-import-%s" % (args.db, datetime.now().strftime("%Y%m%d-%H%M%S"))
    shutil.copy(args.db, bak)
    print("已备份数据库到 %s" % bak)

    db = sqlite3.connect(args.db)
    db.row_factory = sqlite3.Row
    ensure_status_column(db)

    nv = nd = nc = 0
    sv = sd = sc = 0

    for v in data["vehicles"]:
        row = db.execute("SELECT id FROM vehicles WHERE plate = ?",
                         (v["plate"],)).fetchone()
        if row:
            sv += 1
            continue
        db.execute(
            """INSERT INTO vehicles (code, plate, brand_model, dealer,
                 upstream_plan, in_date, upstream_start, deposit,
                 monthly_payment, periods, insurance_plan, ownership,
                 inspection_due, insurance_due, notes, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (v["code"], v["plate"], v.get("brand_model"), v.get("dealer"),
             v.get("upstream_plan"), v.get("in_date"), v.get("upstream_start"),
             v.get("deposit"), v.get("monthly_payment"), v.get("periods"),
             v.get("insurance_plan"), v.get("ownership"),
             v.get("inspection_due"), v.get("insurance_due"),
             v.get("notes"), v.get("status") or "正常"))
        nv += 1

    for d in data["drivers"]:
        if not d.get("phone"):
            sd += 1
            print("跳过司机 %s：没有电话" % d["code"])
            continue
        row = db.execute("SELECT id FROM drivers WHERE code = ?",
                         (d["code"],)).fetchone()
        if row:
            sd += 1
            continue
        db.execute(
            """INSERT INTO drivers (code, name, phone, id_card, address,
                 license_status, ride_license_status, bank,
                 bank_account_name, bank_account, emergency_contact, notes)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (d["code"], d["name"], d["phone"], d.get("id_card"),
             d.get("address"), d.get("license_status"),
             d.get("ride_license_status"), d.get("bank"),
             d.get("bank_account_name"), d.get("bank_account"),
             d.get("emergency_contact"), d.get("notes")))
        nd += 1

    for c in data["checkouts"]:
        code = c["code"]
        row = db.execute("SELECT id FROM checkouts WHERE code = ?",
                         (code,)).fetchone()
        if row:
            sc += 1
            continue
        vrow = db.execute("SELECT id FROM vehicles WHERE plate = ?",
                          (c["plate"],)).fetchone()
        drow = db.execute("SELECT id FROM drivers WHERE code = ?",
                          (c["driver_code"],)).fetchone()
        if not vrow or not drow:
            sc += 1
            print("跳过出库 %s：车辆或司机不在库里" % code)
            continue
        db.execute(
            """INSERT INTO checkouts (code, vehicle_id, driver_id,
                 checkout_date, mode, rent_months, contract_start, coop_end,
                 monthly_rent, deposit_total, deposit_paid, rent_cycle,
                 agreed_amount, service_fee, notes, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (code, vrow["id"], drow["id"], c["checkout_date"], c["mode"],
             c.get("rent_months"), c["contract_start"], c.get("coop_end"),
             c.get("monthly_rent"), c.get("deposit_total"),
             c.get("deposit_paid"), c.get("rent_cycle"),
             c.get("agreed_amount"), c.get("service_fee"), c.get("notes"),
             c.get("status") or "使用中"))
        nc += 1

    db.commit()
    print("导入完成：车辆新增 %d（跳过 %d），司机新增 %d（跳过 %d），"
          "出库新增 %d（跳过 %d）" % (nv, sv, nd, sd, nc, sc))
    print("注意：users 表没有动，账号密码没变。")
    n_v = db.execute(
        "SELECT COUNT(*) FROM vehicles WHERE ownership = '自营'").fetchone()[0]
    n_s = db.execute(
        "SELECT COUNT(*) FROM vehicles WHERE ownership = '自营' "
        "AND status = '停运'").fetchone()[0]
    n_c = db.execute(
        "SELECT COUNT(*) FROM checkouts WHERE status = '使用中'").fetchone()[0]
    print("校验：自营板块车辆 %d 辆，其中停运 %d 辆；使用中出库 %d 单。"
          % (n_v, n_s, n_c))
    db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
