# -*- coding: utf-8 -*-
"""盛亿联合出行 - 车辆出入库联动台账 v1
Flask + SQLite，手机优先。启动: python3 app.py (0.0.0.0:5000)
数据库 ledger.db 在程序目录下，首次启动自动建表并建管理员 admin / admin123。
"""
import math
import os
import re
import sqlite3
from calendar import monthrange
from datetime import date, datetime, timedelta
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template,
                   request, send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from contracts_text import COOP_PARAGRAPHS, LEASE_PARAGRAPHS

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ledger.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads", "drivers")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "shengyi-ledger-v1-change-me")
app.config["JSON_AS_ASCII"] = False
# 证件照片上传: 单次请求最多 32MB(4 张手机照片够用)。
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024

UPSTREAM_PLANS = ["兜车", "以租代购（押金3000）", "以租代购（首付4000）"]
LICENSE_STATUS = ["有效", "已过期", "无"]
MODES = ["纯租", "合作模式"]
RENT_CYCLES = ["日付", "周付", "月付", "流水扣"]
# 销售版块: 意向程度 / 跟进状态。
INTENT_LEVELS = ["高", "中", "低"]
PROSPECT_STATUS = ["跟进中", "已签约", "已流失"]
# 品牌型号(现有 5 款 + 新增 3 款)。
BRAND_MODELS = ["广汽埃安S530", "枫叶S60", "东风E70", "新北汽EU5", "启辰D60",
                "东风风神Pro", "小鹏P5", "启辰D60Pro"]
# 车商(上游公司)。
DEALERS = ["翔途", "扬邦", "喜滴", "汇鲸", "坤祺", "智驾汇"]
# 合同甲方: 按车的上游来源定, 只有两个。
# 自营车 -> 盛亿; 智驾汇的车(板块是智驾汇, 或车商是智驾汇/卓远) -> 智驾汇。
PARTY_A = {
    "盛亿": ("福州市盛亿联合出行服务有限公司",
             "福建省福州市仓山区仓山科技园27号2#楼301室"),
    # 智驾汇的办公地址未确认, 先留空到店手写, 等用户给。
    "智驾汇": ("福州市仓山区智驾汇科技服务有限公司", "＿＿＿＿"),
}
# 司机证件种类: 表单字段名 -> 显示名。
DOC_TYPES = [
    ("id_card_front", "身份证正面"),
    ("id_card_back", "身份证反面"),
    ("driver_license", "驾驶证"),
    ("ride_license_doc", "网约车驾驶员证"),
]
ALLOWED_DOC_EXTS = {"jpg", "jpeg", "png", "pdf"}


# ---------- 数据库 ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'sales',
            created_at TEXT NOT NULL DEFAULT (date('now'))
        );
        CREATE TABLE IF NOT EXISTS vehicles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            plate TEXT UNIQUE NOT NULL,
            brand_model TEXT,
            dealer TEXT,
            upstream_plan TEXT,
            in_date TEXT NOT NULL,
            upstream_start TEXT,
            deposit REAL,
            monthly_payment REAL,
            periods INTEGER,
            insurance_plan TEXT,
            ownership TEXT,
            inspection_due TEXT,
            insurance_due TEXT,
            notes TEXT,
            status TEXT NOT NULL DEFAULT '正常'
        );
        CREATE TABLE IF NOT EXISTS drivers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT,
            id_card TEXT,
            address TEXT,
            license_status TEXT,
            ride_license_status TEXT,
            bank TEXT,
            bank_account_name TEXT,
            bank_account TEXT,
            emergency_contact TEXT,
            notes TEXT
        );
        CREATE TABLE IF NOT EXISTS driver_documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            driver_id INTEGER NOT NULL REFERENCES drivers(id),
            doc_type TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            original_name TEXT NOT NULL,
            uploaded_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS checkouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
            driver_id INTEGER NOT NULL REFERENCES drivers(id),
            checkout_date TEXT NOT NULL,
            mode TEXT NOT NULL,
            rent_months INTEGER,
            contract_start TEXT NOT NULL,
            coop_end TEXT,
            monthly_rent REAL,
            deposit_total REAL,
            deposit_paid REAL,
            rent_cycle TEXT,
            agreed_amount REAL,
            notes TEXT,
            status TEXT NOT NULL DEFAULT '使用中',
            return_date TEXT,
            return_mileage REAL,
            return_condition TEXT,
            return_pending_amount REAL,
            return_notes TEXT
        );
        CREATE TABLE IF NOT EXISTS daily_revenue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            checkout_id INTEGER NOT NULL REFERENCES checkouts(id),
            revenue_date TEXT NOT NULL,
            platform TEXT,
            amount REAL NOT NULL,
            rest_reported INTEGER NOT NULL DEFAULT 0,
            vehicle_reason INTEGER NOT NULL DEFAULT 0,
            notes TEXT,
            UNIQUE(checkout_id, revenue_date)
        );
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            checkout_id INTEGER NOT NULL REFERENCES checkouts(id),
            kind TEXT NOT NULL,
            due_date TEXT,
            pay_date TEXT NOT NULL,
            amount REAL NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        );
        CREATE TABLE IF NOT EXISTS prospects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            phone TEXT,
            wechat_name TEXT,
            current_company TEXT,
            expiry_date TEXT,
            intent_level TEXT,
            owner TEXT,
            last_chat TEXT,
            status TEXT NOT NULL DEFAULT '跟进中',
            last_followup_date TEXT,
            created_at TEXT NOT NULL DEFAULT (date('now')),
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS prospect_followups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prospect_id INTEGER NOT NULL REFERENCES prospects(id),
            followup_date TEXT NOT NULL,
            content TEXT NOT NULL,
            created_by TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        );
    """)
    # 迁移: 老库(骨架建的)没有 service_fee 列, 启动时补上(合作合同打印要用到)。
    cols = [r[1] for r in db.execute("PRAGMA table_info(checkouts)")]
    if "service_fee" not in cols:
        db.execute("ALTER TABLE checkouts ADD COLUMN service_fee REAL")
    # 迁移: 老库没有 status 列, 启动时补上(车辆停运标记, 默认正常)。
    cols_v = [r[1] for r in db.execute("PRAGMA table_info(vehicles)")]
    if "status" not in cols_v:
        db.execute("ALTER TABLE vehicles ADD COLUMN status TEXT NOT NULL DEFAULT '正常'")
    # 迁移: 老库没有 email 列, 启动时补上(司机电子邮箱, 合同送达用)。
    cols_d = [r[1] for r in db.execute("PRAGMA table_info(drivers)")]
    if "email" not in cols_d:
        db.execute("ALTER TABLE drivers ADD COLUMN email TEXT")
    # 迁移: users 表补 phone 列(手机号, 建账号时可填)。
    cols_u = [r[1] for r in db.execute("PRAGMA table_info(users)")]
    if "phone" not in cols_u:
        db.execute("ALTER TABLE users ADD COLUMN phone TEXT")
    # 迁移: 老的默认管理员 admin 改成老板角色(用户名还是 admin)。
    # 注意: 这里的 db 是裸连接(没有 row_factory), 行用下标取。
    row = db.execute("SELECT id, role FROM users WHERE username='admin'").fetchone()
    if row is None:
        db.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'boss')",
            ("admin", generate_password_hash("admin123")),
        )
        print("已创建默认管理员账号: admin / admin123 (请尽快改密码)")
    elif row[1] == "admin":
        db.execute("UPDATE users SET role='boss' WHERE username='admin'")
    # 种子账号(幂等: 用户名已存在就不插)。初始密码是各人手机号后 6 位,
    # 这里只存哈希, 明文密码不进代码。
    seeds = [
        ("欣欣", "sales", "13328657051",
         "pbkdf2:sha256:1000000$QnQwwQWF0xxhbm3O$cb4026d37ebb8f1ffcda20e7a263c145a4dcab60f211a052c5db6ca47667cab1"),
        ("筱筱", "sales", "19204935232",
         "pbkdf2:sha256:1000000$cuzlEV6rAO0aOxz5$3980c2811150268a988ab1a22ef037839751ad9e66eed27fe37f4592296d055a"),
        ("服务中心", "sales", "15980140578",
         "pbkdf2:sha256:1000000$6yoGBi3j4RJVqGox$6a5f7a94f7af77b653421755d580063602d630cb063badc51e614d7480b08acb"),
        ("驾培中心", "sales", "13313985031",
         "pbkdf2:sha256:1000000$ABnPkAXJI7E0i6si$463a367e3579973cfc108ab370ff436ab8eba778343b6962600ad973279c4801"),
        ("媛媛", "sales", "17359112368",
         "pbkdf2:sha256:1000000$IgLY7hBIPzUfjwP4$f304322b8a973500cd7097ad73d29275646e71922fc1ed82d035de12e289891a"),
        ("兮兮", "admin", "17359118505",
         "pbkdf2:sha256:1000000$ws0tOwwxNKBAcTUT$f409605f048bb7880aa44ae532a4afce169d973620f87ebf9ad4505d06755564"),
        ("密姐", "boss", "13959190281",
         "pbkdf2:sha256:1000000$UsqshbJq5aIb06cM$2d60e8c98862e9adcc76047288a14d9d6371d981a0f459ce899a547faceef2b2"),
    ]
    for username, role, phone, pw_hash in seeds:
        if db.execute("SELECT id FROM users WHERE username=?",
                      (username,)).fetchone() is None:
            db.execute(
                "INSERT INTO users (username, password_hash, role, phone) "
                "VALUES (?, ?, ?, ?)",
                (username, pw_hash, role, phone))
    db.commit()
    db.close()


def next_code(table, prefix):
    """按顺序生成编号: V001 / D001 / CK001。"""
    db = get_db()
    rows = db.execute(f"SELECT code FROM {table}").fetchall()
    used = set()
    for r in rows:
        code = (r["code"] or "")
        if code.startswith(prefix):
            try:
                used.add(int(code[len(prefix):]))
            except ValueError:
                pass
    n = 1
    while n in used:
        n += 1
    return f"{prefix}{n:03d}"


# ---------- 小工具 ----------
def parse_date(s):
    if not s:
        return None
    try:
        return datetime.strptime(str(s).strip()[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def parse_money(s):
    if s is None or str(s).strip() == "":
        return None
    try:
        v = float(s)
    except (TypeError, ValueError):
        return None
    return v if v >= 0 else None


def parse_int(s):
    if s is None or str(s).strip() == "":
        return None
    try:
        return int(float(s))
    except (TypeError, ValueError):
        return None


def fmt_money(v):
    if v is None:
        return "—"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return "—"
    if f == int(f):
        return f"{int(f):,}"
    return f"{f:,.2f}"


def fmt_num(v):
    """合同打印里用的数字: 不带千分位, 整数不带小数, 小数最多两位。"""
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if f == int(f):
        return str(int(f))
    return f"{f:.2f}".rstrip("0").rstrip(".")


def round_excel(x):
    """Excel ROUND(x,0): 四舍五入取整(0.5 往大取), 金额都是非负数。
    注意 Python 内置 round 是银行家舍入, 不能直接用。"""
    return int(math.floor(float(x) + 0.5))


def rmb_upper(amount):
    """人民币大写, 与 Excel 的 TEXT(金额,"[DBNum2]")&"元整" 一致。
    3000 -> 叁仟元整; 100.73 -> 壹佰元柒角叁分; 0.5 -> 伍角。"""
    if amount is None:
        return None
    try:
        amt = float(amount)
    except (TypeError, ValueError):
        return None
    if amt < 0:
        return None
    digits = "零壹贰叁肆伍陆柒捌玖"
    units = "分角元拾佰仟万拾佰仟亿拾佰仟"
    cents = int(round(amt * 100))
    if cents == 0:
        return "零元整"
    s = str(cents)
    res = ""
    for i, ch in enumerate(s):
        res += digits[int(ch)] + units[len(s) - 1 - i]
    res = res.replace("零拾", "零").replace("零佰", "零").replace("零仟", "零")
    res = res.replace("零万", "万").replace("零亿", "亿")
    while "零零" in res:
        res = res.replace("零零", "零")
    res = res.replace("零元", "元")
    if res.endswith("零角零分"):
        res = res[:-4] + "整"
    elif res.endswith("零分"):
        res = res[:-2]
    res = res.replace("零角", "零")
    if res.endswith("元"):
        res += "整"
    return res


def fmt_cn_date(d):
    """日期 -> 2026年9月1日(与 Excel TEXT(日期,"yyyy年m月d日") 一致)。"""
    if d is None:
        return None
    return f"{d.year}年{d.month}月{d.day}日"


def warn_bucket(days_left):
    """到期预警档位(与 Excel 到期预警表一致): 剩余天数 -> 档位。
    days_left 为 None 表示到期日未填。"""
    if days_left is None:
        return "未填"
    if days_left < 0:
        return "已过期"
    if days_left <= 7:
        return "7天内到期"
    if days_left <= 30:
        return "30天内到期"
    return "正常"


def add_months(d, months):
    if d is None or not months:
        return None
    total = (d.year * 12 + (d.month - 1)) + int(months)
    year, month = divmod(total, 12)
    month += 1
    day = min(d.day, monthrange(year, month)[1])
    return date(year, month, day)


def contract_end_of(co):
    """合同到期日: 纯租 = 合同开始日 + 租期月数; 合作 = 合作约定到期日。"""
    start = parse_date(co["contract_start"])
    if co["mode"] == "纯租":
        return add_months(start, co["rent_months"])
    return parse_date(co["coop_end"])


def rent_amount_of(co):
    """一期应收金额: 有约定金额用约定金额, 否则按月租算。
    与 Excel 收租日历 F 列一致: 日付 ROUND(月租/30,0), 周付 ROUND(月租/30*7,0)。
    两者都没有返回 None, 表示算不出来, 不计入应收。"""
    if co["agreed_amount"] is not None:
        return float(co["agreed_amount"])
    rent = co["monthly_rent"]
    if rent is None:
        return None
    if co["rent_cycle"] == "日付":
        return float(round_excel(float(rent) / 30))
    if co["rent_cycle"] == "周付":
        return float(round_excel(float(rent) * 7 / 30))
    if co["rent_cycle"] == "月付":
        return float(rent)
    return None


def paid_for(db, checkout_id, kind, due_date=None):
    """某出库某类已收金额。租金按应收日(due_date)汇总, 押金不分应收日。"""
    if kind == "rent" and due_date is not None:
        row = db.execute(
            "SELECT COALESCE(SUM(amount), 0) s FROM payments "
            "WHERE checkout_id = ? AND kind = 'rent' AND due_date = ?",
            (checkout_id, due_date),
        ).fetchone()
    else:
        row = db.execute(
            "SELECT COALESCE(SUM(amount), 0) s FROM payments "
            "WHERE checkout_id = ? AND kind = ?",
            (checkout_id, kind),
        ).fetchone()
    return float(row["s"] or 0)


def deposit_paid_total(db, co):
    """押金实交总额: 提车实交 + 之后补收的押金。"""
    return float(co["deposit_paid"] or 0) + paid_for(db, co["id"], "deposit")


def deposit_owed_of(db, co):
    """押金尚欠: 应交 − 实交总额, 不小于 0。"""
    total = co["deposit_total"]
    if total is None:
        return None
    return max(0.0, float(total) - deposit_paid_total(db, co))


def rent_due_dates(co, from_date, to_date):
    """某纯租出库在 [from_date, to_date] 内的全部收租日(按周期推算)。
    日付每天, 周付每7天, 月付每月同一日(月末自动顺延到当月最后一天)。"""
    if co["mode"] != "纯租":
        return []
    cycle = co["rent_cycle"]
    if cycle not in ("日付", "周付", "月付"):
        return []
    start = parse_date(co["contract_start"])
    if start is None:
        return []
    end = contract_end_of(co)
    stop = to_date if end is None else min(to_date, end)
    out = []
    if cycle == "日付":
        d = max(start, from_date)
        while d <= stop:
            out.append(d)
            d += timedelta(days=1)
    elif cycle == "周付":
        d = start
        while d <= stop:
            if d >= from_date:
                out.append(d)
            d += timedelta(days=7)
    else:  # 月付
        d = start
        while d <= stop:
            if d >= from_date:
                out.append(d)
            nxt = add_months(d, 1)
            if nxt is None or nxt <= d:
                break
            d = nxt
    return out


def next_unpaid_due(db, co, today):
    """下一次未结清的收租日及尚欠金额。返回 (日期, 尚欠) 或 (None, 0)。
    只看使用中纯租; 流水扣 / 周期未填 / 合同已到期返回 None。
    往后最多推算 370 天, 防止死循环。"""
    if co["mode"] != "纯租":
        return None, 0.0
    cycle = co["rent_cycle"]
    if cycle not in ("日付", "周付", "月付"):
        return None, 0.0
    start = parse_date(co["contract_start"])
    if start is None:
        return None, 0.0
    end = contract_end_of(co)
    if end is not None and end < today:
        return None, 0.0
    amt = rent_amount_of(co)
    if amt is None:
        return None, 0.0
    horizon = today + timedelta(days=370)
    for d in rent_due_dates(co, max(today, start), horizon):
        remain = amt - paid_for(db, co["id"], "rent", d.isoformat())
        if remain > 0:
            return d, remain
    return None, 0.0


def next_rent_date_of(co, today):
    """下次收租日。只算使用中纯租, 流水扣没有固定收租日返回 None。
    与 Excel 收租日历 E 列一致:
    日付: 每天都收, 下次就是今天(合同开始日在未来时为开始日)。
    周付: 合同开始日起每 7 天收一次(开始日、开始日+7天、+14天……),
    即开始日 + 7×MAX(0, CEILING((今天-开始日)/7, 1))。
    月付: 合同开始日起每月同一日收一次(月末顺延到当月最后一天)。"""
    if co["mode"] != "纯租":
        return None
    cycle = co["rent_cycle"]
    if cycle not in ("日付", "周付", "月付"):
        return None
    start = parse_date(co["contract_start"])
    if start is None:
        return None
    end = contract_end_of(co)
    if end is not None and end < today:
        return None  # 合同已到期, 不算
    if cycle == "日付":
        nxt = max(today, start)
    elif cycle == "周付":
        if today <= start:
            nxt = start
        else:
            days = (today - start).days
            k = -(-days // 7)  # 向上取整
            nxt = start + timedelta(days=7 * k)
    else:  # 月付
        nxt = start
        while nxt < today:
            nxt = add_months(nxt, 1)
            if nxt is None:
                return None
    if end is not None and nxt > end:
        return None
    return nxt


def rent_dates_in_month(co, year, month):
    """某辆使用中纯租车在指定月份里的全部收租日(周付含开始日本身, 与 Excel 一致)。
    返回 [(日期, 金额或None)]。流水扣 / 周期未填 / 合作模式返回空列表。"""
    if co["mode"] != "纯租":
        return []
    cycle = co["rent_cycle"]
    if cycle not in ("日付", "周付", "月付"):
        return []
    start = parse_date(co["contract_start"])
    if start is None:
        return []
    end = contract_end_of(co)
    first = date(year, month, 1)
    last = date(year, month, monthrange(year, month)[1])
    amt = rent_amount_of(co)
    out = []
    if cycle == "日付":
        d = max(start, first)
        stop = min(end, last) if end is not None else last
        while d <= stop:
            out.append((d, amt))
            d += timedelta(days=1)
    elif cycle == "周付":
        d = start
        while d <= last:
            if d >= first and (end is None or d <= end):
                out.append((d, amt))
            d += timedelta(days=7)
    else:  # 月付
        d = start
        while d <= last:
            if d >= first and (end is None or d <= end):
                out.append((d, amt))
            nxt = add_months(d, 1)
            if nxt is None or nxt <= d:
                break
            d = nxt
    return out


def active_checkout_for_vehicle(vehicle_id):
    db = get_db()
    return db.execute(
        """SELECT c.*, d.name AS driver_name, d.phone AS driver_phone
           FROM checkouts c JOIN drivers d ON d.id = c.driver_id
           WHERE c.vehicle_id = ? AND c.status = '使用中' LIMIT 1""",
        (vehicle_id,),
    ).fetchone()


def active_checkout_for_driver(driver_id):
    db = get_db()
    return db.execute(
        """SELECT c.*, v.plate AS plate, v.code AS vehicle_code
           FROM checkouts c JOIN vehicles v ON v.id = c.vehicle_id
           WHERE c.driver_id = ? AND c.status = '使用中' LIMIT 1""",
        (driver_id,),
    ).fetchone()


# ---------- 登录 ----------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        if session.get("role") not in ("boss", "admin"):
            flash("只有老板和管理员能进这里。")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapper


def boss_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        if session.get("role") != "boss":
            flash("只有老板能进这里。")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapper


@app.context_processor
def inject_user():
    return {"current_user": session.get("username"),
            "current_role": session.get("role")}


@app.route("/")
def index():
    return redirect(url_for("dashboard"))


@app.route("/login", methods=["GET", "POST"])
def login():
    # 已登录就直接去仪表盘, 别再显示登录框(登录页要干净, 不带导航)。
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?",
                          (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("账号或密码不对, 请再试一次。")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        old = request.form.get("old_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE id = ?",
                          (session["user_id"],)).fetchone()
        if not user or not check_password_hash(user["password_hash"], old):
            flash("原密码不对。")
        elif len(new) < 6:
            flash("新密码至少 6 位。")
        elif new != confirm:
            flash("两次输入的新密码不一致。")
        else:
            db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                       (generate_password_hash(new), user["id"]))
            db.commit()
            flash("密码已改好, 下次用新密码登录。")
            return redirect(url_for("dashboard"))
    return render_template("change_password.html")


# ---------- 销售提醒 ----------
def sales_alerts_for(db, today):
    """意向司机提醒(供仪表盘用), 只看跟进中的。
    有到期日: 7 天内(含今天)提醒; 明天到期或已过期加急。
    无到期日: 按上次跟进日(没有则按创建日)算, 超过 10 天没跟进待回访。
    返回 [{p, level(normal/urgent/revisit), days_left, days_since, text}]。"""
    alerts = []
    rows = db.execute(
        "SELECT * FROM prospects WHERE status='跟进中'").fetchall()
    for p in rows:
        exp = parse_date(p["expiry_date"])
        if exp is not None:
            dl = (exp - today).days
            if dl < 0:
                alerts.append({"p": p, "level": "urgent", "days_left": dl,
                               "days_since": None,
                               "text": "已过期 %d 天" % (-dl)})
            elif dl == 1:
                alerts.append({"p": p, "level": "urgent", "days_left": dl,
                               "days_since": None, "text": "明天到期"})
            elif dl <= 7:
                text = "今天到期" if dl == 0 else "还有 %d 天到期" % dl
                alerts.append({"p": p, "level": "normal", "days_left": dl,
                               "days_since": None, "text": text})
        else:
            ref = parse_date(p["last_followup_date"]) or parse_date(p["created_at"])
            if ref is None:
                continue
            ds = (today - ref).days
            if ds > 10:
                alerts.append({"p": p, "level": "revisit", "days_left": None,
                               "days_since": ds,
                               "text": "%d 天没跟进，待回访" % ds})
    order = {"urgent": 0, "normal": 1, "revisit": 2}
    alerts.sort(key=lambda a: (order[a["level"]],
                               a["days_left"] if a["days_left"] is not None else 0))
    return alerts


# ---------- 仪表盘 ----------
@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    today = date.today()
    in7 = today + timedelta(days=7)
    vehicles = db.execute("SELECT * FROM vehicles").fetchall()
    actives = db.execute(
        """SELECT c.*, v.plate AS plate, d.name AS driver_name
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           WHERE c.status = '使用中'""").fetchall()
    active_ids = {c["vehicle_id"] for c in actives}
    total = len(vehicles)
    out_count = len(active_ids)
    in_stock = total - out_count
    # 合同总数: 与合同管理页同一口径(能连上车辆+司机的出库记录), 两边数字一致。
    contract_total = db.execute(
        """SELECT COUNT(*) c FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id""").fetchone()["c"]

    today_items, week_items = [], []
    today_amt, week_amt = 0.0, 0.0
    month_n, month_amt = 0, 0.0
    deposit_owed = 0.0
    expired = 0
    expiring7 = 0
    first = date(today.year, today.month, 1)
    last = date(today.year, today.month, monthrange(today.year, today.month)[1])
    for co in actives:
        owed = deposit_owed_of(db, co)
        if owed:
            deposit_owed += owed
        end = contract_end_of(co)
        if end is not None:
            if end < today:
                expired += 1
            elif end <= in7:
                expiring7 += 1
        # 本月应收: 本月内每个未结清收租日的尚欠之和(已收的扣掉, 新增合同自动加进来)。
        amt = rent_amount_of(co)
        if amt is not None:
            for d in rent_due_dates(co, first, last):
                remain = amt - paid_for(db, co["id"], "rent", d.isoformat())
                if remain > 0:
                    month_n += 1
                    month_amt += remain
        # 今日 / 未来 7 天: 下一次未结清的收租日。
        nxt, remain = next_unpaid_due(db, co, today)
        if nxt is None:
            continue
        item = {"co": co, "due": nxt, "remain": remain}
        if nxt == today:
            today_items.append(item)
            today_amt += remain
        if today < nxt <= in7:
            week_items.append(item)
            week_amt += remain
    stats = {
        "total": total, "in_stock": in_stock, "out_count": out_count,
        "contract_total": contract_total,
        "today_n": len(today_items), "today_amt": today_amt,
        "today_drivers": [it["co"]["driver_name"] for it in today_items],
        "week_n": len(week_items), "week_amt": week_amt,
        "week_drivers": [it["co"]["driver_name"] for it in week_items],
        "month_n": month_n, "month_amt": month_amt,
        "deposit_owed": deposit_owed,
        "expired": expired, "expiring7": expiring7,
        "today": today.isoformat(),
    }
    sales_alerts = sales_alerts_for(db, today)
    sales_urgent = [a for a in sales_alerts
                    if a["level"] in ("urgent", "revisit")]
    return render_template("dashboard.html", stats=stats, fmt_money=fmt_money,
                           sales_alerts=sales_alerts,
                           sales_urgent=sales_urgent)


# ---------- 车辆 ----------
SECTIONS = ["自营", "智驾汇", "车商"]


@app.route("/vehicles")
@login_required
def vehicles():
    db = get_db()
    q = request.args.get("q", "").strip()
    section = request.args.get("section", "").strip()
    if section not in SECTIONS:
        section = ""
    # 状态筛选: 在库=没有使用中出库(含停运), 已出库=有使用中出库。
    status = request.args.get("status", "").strip()
    if status not in ("在库", "已出库"):
        status = ""
    conds = []
    params = []
    if section:
        conds.append("ownership = ?")
        params.append(section)
    if q:
        conds.append("plate LIKE ?")
        params.append(f"%{q}%")
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    rows = db.execute(f"SELECT * FROM vehicles{where} ORDER BY code",
                      params).fetchall()
    counts = {"全部": 0}
    for s in SECTIONS:
        counts[s] = 0
    for r in db.execute(
            "SELECT ownership, COUNT(*) c FROM vehicles GROUP BY ownership"):
        counts["全部"] += r["c"]
        if r["ownership"] in counts:
            counts[r["ownership"]] = r["c"]
    items = []
    for v in rows:
        vstatus = (v["status"] if "status" in v.keys() else None) or "正常"
        if vstatus == "停运":
            items.append({"v": v, "active": None, "status": "停运"})
        else:
            co = active_checkout_for_vehicle(v["id"])
            items.append({"v": v, "active": co,
                          "status": "已出库" if co else "在库"})
    if status == "在库":
        items = [it for it in items if it["status"] != "已出库"]
    elif status == "已出库":
        items = [it for it in items if it["status"] == "已出库"]
    return render_template("vehicles.html", items=items, q=q, section=section,
                           status=status,
                           sections=SECTIONS, counts=counts,
                           fmt_money=fmt_money)


@app.route("/vehicles/new", methods=["GET", "POST"])
@login_required
def vehicle_new():
    if request.method == "POST":
        plate = request.form.get("plate", "").strip()
        in_date = request.form.get("in_date", "").strip()
        if not plate or not in_date:
            flash("车牌号和入库日期是必填的。")
            return render_template("vehicle_form.html", v=None,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        ownership = request.form.get("ownership", "").strip()
        if ownership not in ("自营", "智驾汇", "车商"):
            flash("板块要选一个：自营、智驾汇或车商。")
            return render_template("vehicle_form.html", v=None,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        brand_model = request.form.get("brand_model", "").strip()
        if not brand_model:
            flash("品牌 / 型号要选一个。")
            return render_template("vehicle_form.html", v=None,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        # 自营才要上游方案; 智驾汇、车商代发的不用选。
        upstream_plan = request.form.get("upstream_plan") or None
        if ownership == "自营" and not upstream_plan:
            flash("自营车要选上游方案。")
            return render_template("vehicle_form.html", v=None,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        if parse_date(in_date) is None:
            flash("入库日期格式不对。")
            return render_template("vehicle_form.html", v=None,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        db = get_db()
        if db.execute("SELECT id FROM vehicles WHERE plate = ?",
                      (plate,)).fetchone():
            flash(f"车牌 {plate} 已经有了, 不能重复加。")
            return render_template("vehicle_form.html", v=None,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        vstatus = request.form.get("status", "").strip()
        if vstatus not in ("正常", "停运"):
            vstatus = "正常"
        # 销售看不到上游月供和押金字段, 提交了也忽略(新车就空着)。
        is_sales = session.get("role") == "sales"
        deposit = None if is_sales else parse_money(request.form.get("deposit"))
        monthly_payment = None if is_sales else parse_money(request.form.get("monthly_payment"))
        db.execute(
            """INSERT INTO vehicles (code, plate, brand_model, dealer, upstream_plan,
                 in_date, upstream_start, deposit, monthly_payment, periods,
                 insurance_plan, ownership, inspection_due, insurance_due, notes, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (next_code("vehicles", "V"), plate,
             brand_model,
             request.form.get("dealer", "").strip() or None,
             upstream_plan,
             in_date,
             request.form.get("upstream_start") or None,
             deposit,
             monthly_payment,
             parse_int(request.form.get("periods")),
             request.form.get("insurance_plan", "").strip() or None,
             ownership,
             request.form.get("inspection_due") or None,
             request.form.get("insurance_due") or None,
             request.form.get("notes", "").strip() or None,
             vstatus))
        db.commit()
        flash(f"车辆 {plate} 已加上。")
        return redirect(url_for("vehicles"))
    return render_template("vehicle_form.html", v=None, plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)


@app.route("/vehicles/<int:vid>/edit", methods=["GET", "POST"])
@login_required
def vehicle_edit(vid):
    db = get_db()
    v = db.execute("SELECT * FROM vehicles WHERE id = ?", (vid,)).fetchone()
    if v is None:
        abort(404)
    if request.method == "POST":
        plate = request.form.get("plate", "").strip()
        in_date = request.form.get("in_date", "").strip()
        if not plate or not in_date:
            flash("车牌号和入库日期是必填的。")
            return render_template("vehicle_form.html", v=v,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        ownership = request.form.get("ownership", "").strip()
        if ownership not in ("自营", "智驾汇", "车商"):
            flash("板块要选一个：自营、智驾汇或车商。")
            return render_template("vehicle_form.html", v=v,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        brand_model = request.form.get("brand_model", "").strip()
        if not brand_model:
            flash("品牌 / 型号要选一个。")
            return render_template("vehicle_form.html", v=v,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        # 自营才要上游方案; 智驾汇、车商代发的不用选。
        upstream_plan = request.form.get("upstream_plan") or None
        if ownership == "自营" and not upstream_plan:
            flash("自营车要选上游方案。")
            return render_template("vehicle_form.html", v=v,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        dup = db.execute(
            "SELECT id FROM vehicles WHERE plate = ? AND id != ?",
            (plate, vid)).fetchone()
        if dup:
            flash(f"车牌 {plate} 已经被别的车用了。")
            return render_template("vehicle_form.html", v=v,
                                   plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)
        vstatus = request.form.get("status", "").strip()
        if vstatus not in ("正常", "停运"):
            vstatus = "正常"
        # 销售提交的编辑: 上游月供和押金不动(保持原来数据库里的值)。
        is_sales = session.get("role") == "sales"
        deposit = v["deposit"] if is_sales else parse_money(request.form.get("deposit"))
        monthly_payment = v["monthly_payment"] if is_sales else parse_money(request.form.get("monthly_payment"))
        db.execute(
            """UPDATE vehicles SET plate=?, brand_model=?, dealer=?, upstream_plan=?,
                 in_date=?, upstream_start=?, deposit=?, monthly_payment=?, periods=?,
                 insurance_plan=?, ownership=?, inspection_due=?, insurance_due=?, notes=?,
                 status=?
               WHERE id=?""",
            (plate, brand_model,
             request.form.get("dealer", "").strip() or None,
             upstream_plan, in_date,
             request.form.get("upstream_start") or None,
             deposit,
             monthly_payment,
             parse_int(request.form.get("periods")),
             request.form.get("insurance_plan", "").strip() or None,
             ownership,
             request.form.get("inspection_due") or None,
             request.form.get("insurance_due") or None,
             request.form.get("notes", "").strip() or None, vstatus, vid))
        db.commit()
        flash(f"车辆 {plate} 已改好。")
        return redirect(url_for("vehicles"))
    return render_template("vehicle_form.html", v=v, plans=UPSTREAM_PLANS, brands=BRAND_MODELS, dealers=DEALERS)


@app.route("/vehicles/<int:vid>/delete", methods=["POST"])
@admin_required
def vehicle_delete(vid):
    db = get_db()
    v = db.execute("SELECT * FROM vehicles WHERE id = ?", (vid,)).fetchone()
    if v is None:
        abort(404)
    co = active_checkout_for_vehicle(vid)
    if co:
        flash(f"这辆车删不了: 正在出库中, 出库编号 {co['code']}, "
              f"司机 {co['driver_name']}。请先收车再删。")
        return redirect(url_for("vehicles"))
    db.execute("DELETE FROM vehicles WHERE id = ?", (vid,))
    db.commit()
    flash(f"车辆 {v['plate']} 已删除。")
    return redirect(url_for("vehicles"))


# ---------- 司机 ----------
@app.route("/drivers")
@login_required
def drivers():
    db = get_db()
    q = request.form.get("q", "").strip() if request.method == "POST" else \
        request.args.get("q", "").strip()
    if q:
        rows = db.execute(
            "SELECT * FROM drivers WHERE name LIKE ? OR phone LIKE ? ORDER BY code",
            (f"%{q}%", f"%{q}%")).fetchall()
    else:
        rows = db.execute("SELECT * FROM drivers ORDER BY code").fetchall()
    items = []
    for d in rows:
        co = active_checkout_for_driver(d["id"])
        items.append({"d": d, "active": co})
    return render_template("drivers.html", items=items, q=q)


def _driver_fields(form):
    # 网约车驾驶员证三选一: 有 / 没有 / 已报名。
    ride = form.get("ride_license_status") or None
    if ride not in ("有", "没有", "已报名"):
        ride = None
    return (
        form.get("name", "").strip(),
        form.get("phone", "").strip(),
        form.get("email", "").strip() or None,
        form.get("id_card", "").strip() or None,
        form.get("address", "").strip() or None,
        form.get("license_status") or None,
        ride,
        form.get("bank", "").strip() or None,
        form.get("bank_account_name", "").strip() or None,
        form.get("bank_account", "").strip() or None,
        form.get("emergency_contact", "").strip() or None,
        form.get("notes", "").strip() or None,
    )


def _save_driver_docs(db, driver_id, files):
    """保存司机证件照片: 每种证件一个文件, 存 uploads/drivers/<司机编号>/。
    同一种证件重新上传会替换旧的(旧文件删掉, 记录更新)。"""
    import time
    for field, label in DOC_TYPES:
        f = files.get(field)
        if f is None or not f.filename:
            continue
        ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
        if ext not in ALLOWED_DOC_EXTS:
            flash(f"{label}只收图片(jpg/png)或 PDF, 这个文件没存。")
            continue
        driver = db.execute("SELECT code FROM drivers WHERE id = ?",
                            (driver_id,)).fetchone()
        if driver is None:
            continue
        folder = os.path.join(UPLOAD_DIR, driver["code"])
        if not os.path.isdir(folder):
            os.makedirs(folder)
        stored = "%s_%d.%s" % (field, int(time.time()), ext)
        f.save(os.path.join(folder, stored))
        old = db.execute(
            "SELECT id, stored_name FROM driver_documents "
            "WHERE driver_id = ? AND doc_type = ?",
            (driver_id, field)).fetchone()
        if old is not None:
            old_path = os.path.join(folder, old["stored_name"])
            if os.path.isfile(old_path):
                os.remove(old_path)
            db.execute("DELETE FROM driver_documents WHERE id = ?",
                       (old["id"],))
        db.execute(
            "INSERT INTO driver_documents "
            "(driver_id, doc_type, stored_name, original_name, uploaded_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (driver_id, field, stored, f.filename,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S")))


def _driver_docs(db, driver_id):
    rows = db.execute(
        "SELECT * FROM driver_documents WHERE driver_id = ? ORDER BY id",
        (driver_id,)).fetchall()
    labels = dict(DOC_TYPES)
    return [{"doc": r, "label": labels.get(r["doc_type"], r["doc_type"])}
            for r in rows]


@app.route("/drivers/new", methods=["GET", "POST"])
@login_required
def driver_new():
    if request.method == "POST":
        fields = _driver_fields(request.form)
        if not fields[0] or not fields[1]:
            flash("姓名和联系电话是必填的。")
            return render_template("driver_form.html", d=None,
                                   license_status=LICENSE_STATUS)
        db = get_db()
        cur = db.execute(
            """INSERT INTO drivers (code, name, phone, email, id_card, address,
                 license_status, ride_license_status, bank, bank_account_name,
                 bank_account, emergency_contact, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (next_code("drivers", "D"),) + fields)
        _save_driver_docs(db, cur.lastrowid, request.files)
        db.commit()
        flash(f"司机 {fields[0]} 已加上。")
        return redirect(url_for("drivers"))
    return render_template("driver_form.html", d=None, docs=[],
                           license_status=LICENSE_STATUS)


@app.route("/drivers/<int:did>/edit", methods=["GET", "POST"])
@login_required
def driver_edit(did):
    db = get_db()
    d = db.execute("SELECT * FROM drivers WHERE id = ?", (did,)).fetchone()
    if d is None:
        abort(404)
    if request.method == "POST":
        fields = _driver_fields(request.form)
        if not fields[0] or not fields[1]:
            flash("姓名和联系电话是必填的。")
            return render_template("driver_form.html", d=d,
                                   docs=_driver_docs(db, did),
                                   license_status=LICENSE_STATUS)
        db.execute(
            """UPDATE drivers SET name=?, phone=?, email=?, id_card=?, address=?,
                 license_status=?, ride_license_status=?, bank=?,
                 bank_account_name=?, bank_account=?, emergency_contact=?, notes=?
               WHERE id=?""",
            fields + (did,))
        _save_driver_docs(db, did, request.files)
        db.commit()
        flash(f"司机 {fields[0]} 已改好。")
        return redirect(url_for("drivers"))
    return render_template("driver_form.html", d=d,
                           docs=_driver_docs(db, did),
                           license_status=LICENSE_STATUS)


@app.route("/drivers/<int:did>/delete", methods=["POST"])
@admin_required
def driver_delete(did):
    db = get_db()
    d = db.execute("SELECT * FROM drivers WHERE id = ?", (did,)).fetchone()
    if d is None:
        abort(404)
    co = active_checkout_for_driver(did)
    if co:
        flash(f"这个司机删不了: 正在出库中, 出库编号 {co['code']}, "
              f"车牌 {co['plate']}。请先收车再删。")
        return redirect(url_for("drivers"))
    db.execute("DELETE FROM drivers WHERE id = ?", (did,))
    db.commit()
    flash(f"司机 {d['name']} 已删除。")
    return redirect(url_for("drivers"))


@app.route("/drivers/<int:did>/docs/<int:doc_id>")
@login_required
def driver_doc_view(did, doc_id):
    """看一张证件照片(登录后才能看, 不对外公开)。"""
    db = get_db()
    doc = db.execute(
        "SELECT dd.*, d.code AS driver_code FROM driver_documents dd "
        "JOIN drivers d ON d.id = dd.driver_id "
        "WHERE dd.id = ? AND dd.driver_id = ?", (doc_id, did)).fetchone()
    if doc is None:
        abort(404)
    folder = os.path.join(UPLOAD_DIR, doc["driver_code"])
    return send_from_directory(folder, doc["stored_name"])


@app.route("/drivers/<int:did>/docs/<int:doc_id>/delete", methods=["POST"])
@admin_required
def driver_doc_delete(did, doc_id):
    db = get_db()
    doc = db.execute(
        "SELECT dd.*, d.code AS driver_code FROM driver_documents dd "
        "JOIN drivers d ON d.id = dd.driver_id "
        "WHERE dd.id = ? AND dd.driver_id = ?", (doc_id, did)).fetchone()
    if doc is None:
        abort(404)
    path = os.path.join(UPLOAD_DIR, doc["driver_code"], doc["stored_name"])
    if os.path.isfile(path):
        os.remove(path)
    db.execute("DELETE FROM driver_documents WHERE id = ?", (doc_id,))
    db.commit()
    flash("这张证件照片已删除。")
    return redirect(url_for("driver_edit", did=did))


# ---------- 出库 / 收车 ----------
@app.route("/checkouts")
@login_required
def checkouts():
    db = get_db()
    status = request.args.get("status", "使用中")
    if status not in ("使用中", "已收车", "全部"):
        status = "使用中"
    mode = request.args.get("mode", "全部")
    if mode not in ("全部", "纯租", "合作模式"):
        mode = "全部"
    base = """SELECT c.*, v.plate AS plate, v.code AS vehicle_code,
                     v.brand_model AS brand_model, d.name AS driver_name,
                     d.phone AS driver_phone
              FROM checkouts c
              JOIN vehicles v ON v.id = c.vehicle_id
              JOIN drivers d ON d.id = c.driver_id"""
    conds, params = [], []
    if status != "全部":
        conds.append("c.status = ?")
        params.append(status)
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    # 模式框里的数字按当前状态算(不含模式筛选), 点进去看到的条数与框里数字一致
    status_rows = db.execute(base + where + " ORDER BY c.id DESC",
                             params).fetchall()
    mode_counts = {"全部": len(status_rows), "纯租": 0, "合作模式": 0}
    for co in status_rows:
        if co["mode"] in mode_counts:
            mode_counts[co["mode"]] += 1
    if mode != "全部":
        rows = [co for co in status_rows if co["mode"] == mode]
    else:
        rows = status_rows
    items = []
    for co in rows:
        items.append({"co": co, "end": contract_end_of(co)})
    return render_template("checkouts.html", items=items, status=status,
                           mode=mode, mode_counts=mode_counts,
                           total=len(rows), fmt_money=fmt_money)


@app.route("/checkouts/new", methods=["GET", "POST"])
@login_required
def checkout_new():
    db = get_db()
    if request.method == "POST":
        vehicle_id = parse_int(request.form.get("vehicle_id"))
        driver_id = parse_int(request.form.get("driver_id"))
        checkout_date = request.form.get("checkout_date", "").strip()
        mode = request.form.get("mode", "")
        contract_start = request.form.get("contract_start", "").strip()
        rent_months = parse_int(request.form.get("rent_months"))
        coop_end = request.form.get("coop_end") or None
        errors = []
        if not vehicle_id:
            errors.append("要选一辆车。")
        if not driver_id:
            errors.append("要选一个司机。")
        if not checkout_date or parse_date(checkout_date) is None:
            errors.append("出库日期必填, 格式要对。")
        if mode not in MODES:
            errors.append("下游模式要选纯租或合作模式。")
        if not contract_start or parse_date(contract_start) is None:
            errors.append("合同开始日必填, 格式要对。")
        if mode == "纯租" and not rent_months:
            errors.append("纯租要填租期(几个月)。")
        if mode == "合作模式" and not coop_end:
            errors.append("合作模式要填合作约定到期日。")
        if parse_money(request.form.get("deposit_total")) is None:
            errors.append("应交押金必填, 不能空着(以后不存在押金未填)。")
        vehicle = (db.execute("SELECT * FROM vehicles WHERE id = ?",
                              (vehicle_id,)).fetchone() if vehicle_id else None)
        driver = (db.execute("SELECT * FROM drivers WHERE id = ?",
                             (driver_id,)).fetchone() if driver_id else None)
        if vehicle_id and not vehicle:
            errors.append("选的车不存在。")
        if driver_id and not driver:
            errors.append("选的司机不存在。")
        if vehicle and active_checkout_for_vehicle(vehicle["id"]):
            errors.append(f"车 {vehicle['plate']} 已经出库了, 不能重复出库。")
        if errors:
            for e in errors:
                flash(e)
        else:
            # 出库时顺手把司机邮箱填上/改掉, 存到司机身上, 合同送达栏跟着变。
            new_email = request.form.get("driver_email", "").strip() or None
            if new_email:
                db.execute("UPDATE drivers SET email=? WHERE id=?",
                           (new_email, driver_id))
            db.execute(
                """INSERT INTO checkouts (code, vehicle_id, driver_id, checkout_date,
                     mode, rent_months, contract_start, coop_end, monthly_rent,
                     deposit_total, deposit_paid, rent_cycle, agreed_amount,
                     service_fee, notes)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (next_code("checkouts", "CK"), vehicle_id, driver_id,
                 checkout_date, mode, rent_months, contract_start, coop_end,
                 parse_money(request.form.get("monthly_rent")),
                 parse_money(request.form.get("deposit_total")),
                 parse_money(request.form.get("deposit_paid")),
                 request.form.get("rent_cycle") or None,
                 parse_money(request.form.get("agreed_amount")),
                 parse_money(request.form.get("service_fee")),
                 request.form.get("notes", "").strip() or None))
            db.commit()
            flash(f"出库已登记: {vehicle['plate']} 出给 {driver['name']}。")
            return redirect(url_for("checkouts"))
    # 下拉只列当前在库的车(停运的车不列, 不能再出库)
    in_stock = db.execute(
        """SELECT * FROM vehicles WHERE id NOT IN
               (SELECT vehicle_id FROM checkouts WHERE status = '使用中')
           AND (status IS NULL OR status != '停运')
           ORDER BY plate""").fetchall()
    drivers = db.execute("SELECT * FROM drivers ORDER BY name").fetchall()
    return render_template("checkout_form.html", vehicles=in_stock,
                           drivers=drivers, modes=MODES,
                           cycles=RENT_CYCLES)


@app.route("/checkouts/<int:cid>/return", methods=["GET", "POST"])
@login_required
def checkout_return(cid):
    db = get_db()
    co = db.execute(
        """SELECT c.*, v.plate AS plate, v.code AS vehicle_code,
                  v.brand_model AS brand_model, d.name AS driver_name,
                  d.phone AS driver_phone
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           WHERE c.id = ?""", (cid,)).fetchone()
    if co is None:
        abort(404)
    if co["status"] != "使用中":
        flash("这条出库已经收过车了。")
        return redirect(url_for("checkouts"))
    if request.method == "POST":
        return_date = request.form.get("return_date", "").strip()
        if not return_date or parse_date(return_date) is None:
            flash("收车日期必填, 格式要对。")
            return render_template("return_form.html", co=co,
                                   end=contract_end_of(co),
                                   fmt_money=fmt_money)
        db.execute(
            """UPDATE checkouts SET status='已收车', return_date=?,
                 return_mileage=?, return_condition=?, return_pending_amount=?,
                 return_notes=? WHERE id=?""",
            (return_date,
             parse_money(request.form.get("return_mileage")),
             request.form.get("return_condition", "").strip() or None,
             parse_money(request.form.get("return_pending_amount")),
             request.form.get("return_notes", "").strip() or None, cid))
        db.commit()
        flash(f"已收车: {co['plate']}, 车辆已回在库。")
        return redirect(url_for("checkouts"))
    return render_template("return_form.html", co=co,
                           end=contract_end_of(co), fmt_money=fmt_money)


# ---------- 账号管理(仅老板) ----------
@app.route("/users", methods=["GET", "POST"])
@boss_required
def users():
    db = get_db()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "sales")
        phone = request.form.get("phone", "").strip() or None
        if not username or len(password) < 6:
            flash("用户名必填, 密码至少 6 位。")
        elif role not in ("boss", "admin", "sales"):
            flash("角色只能是老板、管理员或销售。")
        elif db.execute("SELECT id FROM users WHERE username = ?",
                        (username,)).fetchone():
            flash(f"账号 {username} 已经有了。")
        else:
            db.execute(
                "INSERT INTO users (username, password_hash, role, phone) VALUES (?, ?, ?, ?)",
                (username, generate_password_hash(password), role, phone))
            db.commit()
            flash(f"账号 {username} 已建好。")
        return redirect(url_for("users"))
    rows = db.execute(
        "SELECT id, username, role, phone, created_at FROM users ORDER BY id").fetchall()
    return render_template("users.html", users=rows)


@app.route("/users/<int:uid>/password", methods=["POST"])
@boss_required
def user_set_password(uid):
    db = get_db()
    new = request.form.get("new_password", "")
    user = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if user is None:
        abort(404)
    if len(new) < 6:
        flash("新密码至少 6 位, 没改。")
    else:
        db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                   (generate_password_hash(new), uid))
        db.commit()
        flash(f"账号 {user['username']} 的密码已改好。")
    return redirect(url_for("users"))


@app.route("/users/<int:uid>/delete", methods=["POST"])
@boss_required
def user_delete(uid):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if user is None:
        abort(404)
    if user["id"] == session.get("user_id"):
        flash("不能删自己的账号。")
    elif user["username"] == "admin":
        flash("默认管理员账号不能删。")
    else:
        db.execute("DELETE FROM users WHERE id = ?", (uid,))
        db.commit()
        flash(f"账号 {user['username']} 已删除。")
    return redirect(url_for("users"))


# ---------- 合同打印 ----------
PLACEHOLDER_RE = re.compile(r"\{([a-z_]+)(?::date)?\}")


def rent_cycle_clauses(cycle):
    """按出库选的租金周期, 生成合同里的三处租金条款(第二条第2、3款 + 第七条之一第1款)。
    日付就是日付、周付就是周付、月付就是月付, 不再写死日结。"""
    if cycle == "周付":
        return {
            "rent_unpaid_clause": "租金按周结算, 每7日支付一次, 每期租金须于当期开始前7日付清, 按第三条先从可结算流水扣付; 流水不足支付租金的, 乙方应按时自行补足。自应付时点起逾期超过1日(24小时)仍未结清的, 按第七条处理。",
            "rent_paid_clause": "乙方应于每期开始前7日预付当期租金。任一到期应付租金自应付时点起逾期超过3日(72小时)仍未付清的, 按第七条处理。",
            "rent_prepay_clause": "租金采用预付方式的, 按下列方式支付: 周付的, 每7日支付一次, 须提前7日预付。",
        }
    if cycle == "月付":
        return {
            "rent_unpaid_clause": "租金按月结算, 每月支付一次, 每期租金须于当期开始前7日付清, 按第三条先从可结算流水扣付; 流水不足支付租金的, 乙方应按时自行补足。自应付时点起逾期超过1日(24小时)仍未结清的, 按第七条处理。",
            "rent_paid_clause": "乙方应于每期开始前7日预付当期租金。任一到期应付租金自应付时点起逾期超过3日(72小时)仍未付清的, 按第七条处理。",
            "rent_prepay_clause": "租金采用预付方式的, 按下列方式支付: 月付的, 每月支付一次, 须提前7日预付。",
        }
    if cycle == "流水扣":
        return {
            "rent_unpaid_clause": "租金从乙方运营流水中扣除, 按第三条结算; 流水不足支付租金的, 乙方应按时自行补足。自应付时点起逾期超过1日(24小时)仍未结清的, 按第七条处理。",
            "rent_paid_clause": "租金从乙方运营流水中扣除, 按第三条结算。任一到期应付租金自应付时点起逾期超过3日(72小时)仍未付清的, 按第七条处理。",
            "rent_prepay_clause": "租金从乙方运营流水中扣除, 不适用预付方式。",
        }
    # 日付(默认, 含周期未填): 沿用原合同的日结写法。
    return {
        "rent_unpaid_clause": "租金日结, 每日17时前结清当日租金, 按第三条先从当日可结算流水扣付; 流水不足支付租金的, 乙方应按时自行补足。自应付时点起逾期超过1日(24小时)仍未结清的, 按第七条处理。",
        "rent_paid_clause": "乙方每日18点前预付次日租金。任一到期应付租金自应付时点起逾期超过3日(72小时)仍未付清的, 按第七条处理。",
        "rent_prepay_clause": "租金采用预付方式的, 按下列方式支付: 日付的, 每日支付一次, 须提前1日预付(每日18点前预付次日租金)。",
    }


def contract_context(co):
    """出库行(已 JOIN 车辆/司机) -> 合同占位符字典。
    合同编号 = HT-出库编号(与 Excel 合同数据源 B 列一致)。
    尚欠押金按合同数据源 S 列: 应交或实交任一为空则为空。
    日租金 = ROUND(月租/30,2)(合同数据源 O 列)。"""
    total = co["deposit_total"]
    paid = co["deposit_paid"]
    owed = None
    if total is not None and paid is not None:
        owed = float(total) - float(paid)
    monthly = co["monthly_rent"]
    daily = round(float(monthly) / 30, 2) if monthly is not None else None
    fee = co["service_fee"] if "service_fee" in co.keys() else None
    # 合同甲方: 板块是智驾汇, 或车商是智驾汇/卓远, 就是智驾汇; 其余是盛亿。
    ownership = co["ownership"] if "ownership" in co.keys() else None
    dealer = co["dealer"] if "dealer" in co.keys() else None
    if ownership == "智驾汇" or dealer in ("智驾汇", "卓远"):
        party_a, party_a_address = PARTY_A["智驾汇"]
    else:
        party_a, party_a_address = PARTY_A["盛亿"]
    return {
        "contract_no": "HT-" + (co["code"] or ""),
        "party_a": party_a,
        "party_a_address": party_a_address,
        "plate": co["plate"] or "",
        "brand_model": co["brand_model"] or "",
        "driver_name": co["driver_name"] or "",
        "driver_phone": co["driver_phone"] or "",
        "driver_email": co["driver_email"] or "",
        "driver_id_card": co["driver_id_card"] or "",
        "driver_address": co["driver_address"] or "",
        "monthly_rent": fmt_num(monthly),
        "monthly_rent_upper": rmb_upper(monthly),
        "daily_rent": fmt_num(daily),
        "deposit_total": fmt_num(total),
        "deposit_total_upper": rmb_upper(total),
        "deposit_paid": fmt_num(paid),
        "deposit_owed": fmt_num(owed),
        "service_fee": fmt_num(fee),
        "service_fee_upper": rmb_upper(fee),
        "start_date": parse_date(co["contract_start"]),
        "end_date": contract_end_of(co),
        "checkout_date": parse_date(co["checkout_date"]),
        "bank": co["bank"] or "",
        "bank_account_name": co["bank_account_name"] or "",
        "bank_account": co["bank_account"] or "",
        "rent_cycle": co["rent_cycle"] or "",
        **rent_cycle_clauses(co["rent_cycle"] if "rent_cycle" in co.keys() else None),
    }


def render_contract(paras, ctx):
    """模板段落 -> [(kind, text)]。缺失的值印成空白下划线, 到店手写补。
    kind: title(合同名) / h2(第X条) / h3(第X款小标题/乙方确认声明) / p(正文)。"""
    svc_text = ("车辆交付前的整备、清洁与检查；网约车平台账号的开通、接入与授权办理；"
                "司机运营培训与带教；本合同签订、车辆交接等手续的办理；"
                "以及合作期间的日常运营管理服务。上述服务在车辆实际交付时已履行完毕。")
    out = []
    for i, p in enumerate(paras):
        if p == "__SERVICE_FEE__":
            fee = ctx.get("service_fee")
            fee_up = ctx.get("service_fee_upper")
            if fee:
                first = (f"1. 乙方应向甲方支付服务费人民币{fee}元"
                         f"（大写：{fee_up}）。服务费对应的服务内容为：{svc_text}")
            else:
                first = (f"1. 乙方应向甲方支付服务费人民币____________元。"
                         f"服务费对应的服务内容为：{svc_text}")
            out.append(("p", first))
            out.append(("p", "2. 服务费从乙方运营流水中扣除。服务费一经收取，不予退还。"))
            continue

        def repl(m):
            key = m.group(1)
            val = ctx.get(key)
            if m.group(0).endswith(":date}"):
                return fmt_cn_date(val) if val is not None else "＿＿＿＿"
            if val is None or val == "":
                return "＿＿＿＿"
            return str(val)

        text = PLACEHOLDER_RE.sub(repl, p)
        if p.startswith("开户行：") and ctx.get("bank"):
            text = "开户行：" + ctx["bank"]
        elif p.startswith("户名：") and ctx.get("bank_account_name"):
            text = "户名：" + ctx["bank_account_name"]
        elif p.startswith("账号：") and ctx.get("bank_account"):
            text = "账号：" + ctx["bank_account"]
        if i == 0:
            kind = "title"
        elif p.startswith("第") and "条" in p[:6]:
            kind = "h2"
        elif p == "乙方确认声明" or re.match(r"^[一二三四五六七八九十]+、", p):
            kind = "h3"
        else:
            kind = "p"
        out.append((kind, text))
    return out


def get_checkout_full(cid):
    db = get_db()
    return db.execute(
        """SELECT c.*, v.plate AS plate, v.code AS vehicle_code,
                  v.brand_model AS brand_model, v.ownership AS ownership,
                  v.dealer AS dealer, d.name AS driver_name,
                  d.phone AS driver_phone, d.email AS driver_email,
                  d.id_card AS driver_id_card,
                  d.address AS driver_address, d.bank AS bank,
                  d.bank_account_name AS bank_account_name,
                  d.bank_account AS bank_account
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           WHERE c.id = ?""", (cid,)).fetchone()


@app.route("/contracts")
@login_required
def contracts():
    db = get_db()
    mode = request.args.get("mode", "全部")
    if mode not in ("全部", "纯租", "合作模式"):
        mode = "全部"
    base = """SELECT c.*, v.plate AS plate, v.brand_model AS brand_model,
                  d.name AS driver_name, d.phone AS driver_phone
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id"""
    all_rows = db.execute(base + " ORDER BY c.id DESC").fetchall()
    # 模式框里的数字按全部合同算
    mode_counts = {"全部": len(all_rows), "纯租": 0, "合作模式": 0}
    for co in all_rows:
        if co["mode"] in mode_counts:
            mode_counts[co["mode"]] += 1
    if mode != "全部":
        rows = [co for co in all_rows if co["mode"] == mode]
    else:
        rows = all_rows
    items = [{"co": co, "end": contract_end_of(co)} for co in rows]
    total = len(rows)
    active = sum(1 for co in rows if co["status"] == "使用中")
    return render_template("contracts.html", items=items,
                           total=total, active=active,
                           done=total - active, mode=mode,
                           mode_counts=mode_counts,
                           fmt_money=fmt_money)


@app.route("/contracts/<int:cid>/print")
@login_required
def contract_print(cid):
    co = get_checkout_full(cid)
    if co is None:
        abort(404)
    paras = LEASE_PARAGRAPHS if co["mode"] == "纯租" else COOP_PARAGRAPHS
    title = "网约车车辆租赁合同" if co["mode"] == "纯租" else "网约车车辆合作经营合同"
    ctx = contract_context(co)
    return render_template("contract_print.html", co=co,
                           title=title,
                           sections=render_contract(paras, ctx),
                           end=contract_end_of(co))


# ---------- 收租日历 ----------
def month_grid(year, month):
    """月历格子(周一开头): 每周 7 格, 月外日期为 None。"""
    first = date(year, month, 1)
    last = date(year, month, monthrange(year, month)[1])
    weeks, week = [], [None] * first.weekday()
    d = first
    while d <= last:
        week.append(d)
        if len(week) == 7:
            weeks.append(week)
            week = []
        d += timedelta(days=1)
    if week:
        week += [None] * (7 - len(week))
        weeks.append(week)
    return weeks


@app.route("/rent-calendar")
@login_required
def rent_calendar():
    db = get_db()
    today = date.today()
    try:
        year = int(request.args.get("year", today.year))
        month = int(request.args.get("month", today.month))
        date(year, month, 1)
    except (TypeError, ValueError):
        year, month = today.year, today.month
    prev_y, prev_m = (year - 1, 12) if month == 1 else (year, month - 1)
    next_y, next_m = (year + 1, 1) if month == 12 else (year, month + 1)
    actives = db.execute(
        """SELECT c.*, v.plate AS plate, d.name AS driver_name
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           WHERE c.status = '使用中' AND c.mode = '纯租'
           ORDER BY d.name""").fetchall()
    by_day = {}
    day_sum = {}
    no_date = []
    total_n, total_amt, no_amt_n = 0, 0.0, 0
    for co in actives:
        entries = rent_dates_in_month(co, year, month)
        if not entries:
            reason = "流水扣，无固定收租日" if co["rent_cycle"] == "流水扣" \
                else "收租周期未填"
            no_date.append({"co": co, "reason": reason,
                            "end": contract_end_of(co)})
            continue
        for d, amt in entries:
            total_n += 1
            if amt is None:
                no_amt_n += 1
            else:
                total_amt += amt
            by_day.setdefault(d, []).append(
                {"co": co, "amt": amt})
            s = day_sum.setdefault(d, {"n": 0, "amt": 0.0, "no_amt": 0})
            s["n"] += 1
            if amt is None:
                s["no_amt"] += 1
            else:
                s["amt"] += amt
    return render_template("rent_calendar.html", year=year, month=month,
                           prev_y=prev_y, prev_m=prev_m,
                           next_y=next_y, next_m=next_m,
                           weeks=month_grid(year, month), by_day=by_day,
                           day_sum=day_sum,
                           no_date=no_date, total_n=total_n,
                           total_amt=total_amt, no_amt_n=no_amt_n,
                           today=today, fmt_money=fmt_money)


# ---------- 收租收款(今日应收 / 未来 7 天应收点进来) ----------
@app.route("/rent/collect")
@login_required
def rent_collect():
    db = get_db()
    today = date.today()
    in7 = today + timedelta(days=7)
    scope = request.args.get("scope", "today")
    if scope not in ("today", "week"):
        scope = "today"
    actives = db.execute(
        """SELECT c.*, v.plate AS plate, d.name AS driver_name
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           WHERE c.status = '使用中' AND c.mode = '纯租'
           ORDER BY d.name""").fetchall()
    items = []
    for co in actives:
        nxt, remain = next_unpaid_due(db, co, today)
        if nxt is None:
            continue
        if scope == "today" and nxt != today:
            continue
        if scope == "week" and not (today < nxt <= in7):
            continue
        items.append({"co": co, "due": nxt, "remain": remain,
                      "paid_sofar": rent_amount_of(co) - remain
                      if rent_amount_of(co) else 0})
    title = "今日应收收款" if scope == "today" else "未来 7 天应收收款"
    return render_template("rent_collect.html", items=items, scope=scope,
                           title=title, today=today, fmt_money=fmt_money)


@app.route("/rent/collect", methods=["POST"])
@login_required
def rent_collect_save():
    db = get_db()
    today = date.today()
    scope = request.form.get("scope", "today")
    saved_n, saved_amt = 0, 0.0
    for key, val in request.form.items():
        if not key.startswith("amt_"):
            continue
        try:
            cid = int(key[4:])
        except ValueError:
            continue
        try:
            amount = float(val)
        except (TypeError, ValueError):
            continue
        if amount <= 0:
            continue
        due = request.form.get("due_%d" % cid)
        if not due:
            continue
        co = db.execute("SELECT * FROM checkouts WHERE id = ?",
                        (cid,)).fetchone()
        if co is None or co["status"] != "使用中":
            continue
        db.execute(
            "INSERT INTO payments (checkout_id, kind, due_date, pay_date, amount) "
            "VALUES (?, 'rent', ?, ?, ?)",
            (cid, due, today.isoformat(), amount))
        saved_n += 1
        saved_amt += amount
    db.commit()
    if saved_n:
        flash("已收 %d 笔, 共 %s 元。" % (saved_n, fmt_money(saved_amt)))
    else:
        flash("没有填收款金额, 什么也没保存。")
    return redirect(url_for("dashboard"))


# ---------- 押金提醒 ----------
@app.route("/deposit-alerts")
@login_required
def deposit_alerts():
    show = request.args.get("show", "all")
    db = get_db()
    rows = db.execute(
        """SELECT c.*, v.plate AS plate, d.name AS driver_name
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           WHERE c.status = '使用中' AND c.mode = '纯租' ORDER BY c.id""").fetchall()
    items, owed_total = [], 0.0
    counts = {"未交齐": 0, "已交齐": 0}
    for co in rows:
        total = co["deposit_total"]
        if total is None:
            # 押金未填的旧数据不再单列: 按已交 0 算尚欠, 归入未交齐, 销售补填后即正常。
            total = 0.0
        paid = deposit_paid_total(db, co)
        if paid >= float(total):
            status, owed = "已交齐", 0.0
        else:
            status, owed = "未交齐", float(total) - paid
            owed_total += owed
        counts[status] += 1
        items.append({"co": co, "total": float(total), "paid": paid,
                      "owed": owed, "status": status})
    order = {"未交齐": 0, "已交齐": 1}
    items.sort(key=lambda x: (order[x["status"]],
                              -(x["owed"] or 0)))
    if show == "unpaid":
        items = [it for it in items if it["status"] == "未交齐"]
    elif show == "paid":
        items = [it for it in items if it["status"] == "已交齐"]
    return render_template("deposit_alerts.html", items=items,
                           counts=counts, owed_total=owed_total,
                           fmt_money=fmt_money, show=show)


@app.route("/deposit-alerts", methods=["POST"])
@login_required
def deposit_alerts_save():
    db = get_db()
    today = date.today()
    saved_n, saved_amt = 0, 0.0
    for key, val in request.form.items():
        if not key.startswith("amt_"):
            continue
        try:
            cid = int(key[4:])
        except ValueError:
            continue
        try:
            amount = float(val)
        except (TypeError, ValueError):
            continue
        if amount <= 0:
            continue
        co = db.execute("SELECT * FROM checkouts WHERE id = ?",
                        (cid,)).fetchone()
        if co is None or co["status"] != "使用中":
            continue
        db.execute(
            "INSERT INTO payments (checkout_id, kind, due_date, pay_date, amount) "
            "VALUES (?, 'deposit', NULL, ?, ?)",
            (cid, today.isoformat(), amount))
        saved_n += 1
        saved_amt += amount
    db.commit()
    if saved_n:
        flash("押金已收 %d 笔, 共 %s 元。" % (saved_n, fmt_money(saved_amt)))
    else:
        flash("没有填收款金额, 什么也没保存。")
    return redirect(url_for("dashboard"))


# ---------- 到期预警 ----------
@app.route("/expiry-alerts")
@login_required
def expiry_alerts():
    db = get_db()
    today = date.today()

    def days_left(d):
        return (d - today).days if d is not None else None

    downstream = []
    for co in db.execute(
            """SELECT c.*, v.plate AS plate, d.name AS driver_name
               FROM checkouts c
               JOIN vehicles v ON v.id = c.vehicle_id
               JOIN drivers d ON d.id = c.driver_id
               WHERE c.status = '使用中' ORDER BY c.id""").fetchall():
        end = contract_end_of(co)
        dl = days_left(end)
        downstream.append({"co": co, "end": end, "days": dl,
                           "bucket": warn_bucket(dl)})
    downstream.sort(key=lambda x: (x["days"] is None,
                                   x["days"] if x["days"] is not None else 0))

    vehicles = db.execute("SELECT * FROM vehicles ORDER BY code").fetchall()
    upstream, inspection, insurance = [], [], []
    for v in vehicles:
        up_end = None
        start = parse_date(v["upstream_start"])
        if start is not None and v["periods"]:
            up_end = add_months(start, v["periods"])
        dl = days_left(up_end)
        upstream.append({"v": v, "end": up_end, "days": dl,
                         "bucket": warn_bucket(dl)})
        for lst, col in ((inspection, "inspection_due"),
                         (insurance, "insurance_due")):
            due = parse_date(v[col])
            dl2 = days_left(due)
            lst.append({"v": v, "end": due, "days": dl2,
                        "bucket": warn_bucket(dl2)})

    def counts(items):
        c = {"已过期": 0, "7天内到期": 0, "30天内到期": 0, "正常": 0, "未填": 0}
        for it in items:
            c[it["bucket"]] += 1
        return c

    return render_template("expiry_alerts.html", today=today,
                           downstream=downstream, upstream=upstream,
                           inspection=inspection, insurance=insurance,
                           counts_down=counts(downstream),
                           counts_up=counts(upstream),
                           counts_insp=counts(inspection),
                           counts_ins=counts(insurance))


# ---------- 每日流水 ----------
PLATFORMS = ["安安出行", "喜行约车"]


def revenue_day_info(db, co, rdate, amount):
    """每日流水的自动列(与 Excel 每日流水 J/K/M/N 列一致)。
    返回 (合作第几天, 当日目标, 近3日累计, 连续规则提示)。"""
    start = parse_date(co["contract_start"])
    day_index = (rdate - start).days + 1 if start else None
    target = None
    if co["mode"] == "合作模式":
        if day_index is not None and day_index <= 10:
            target = 220.0
    elif co["mode"] == "纯租":
        if (co["deposit_paid"] or 0) < (co["deposit_total"] or 0):
            target = 280.0
    # 注意: 这里传进来的是 daily_revenue 行(带 checkout_id), 不是出库行,
    # 近3日累计要按出库查, 不能用行自身的 id(那是流水记录的 id)。
    cid = (co["checkout_id"] if "checkout_id" in co.keys()
           else co["id"])
    near3 = db.execute(
        "SELECT COALESCE(SUM(amount),0) FROM daily_revenue "
        "WHERE checkout_id=? AND revenue_date BETWEEN ? AND ?",
        (cid, (rdate - timedelta(days=2)).isoformat(),
         rdate.isoformat())).fetchone()[0]
    tip = ""
    if (co["mode"] == "合作模式" and day_index is not None
            and day_index > 10 and float(near3) < 300):
        tip = "提示：近3日累计低于300，需核对是否存在漏录/报备/车辆原因"
    return day_index, target, float(near3), tip


def revenue_judgement(mode, day_index, target, amount,
                      rest_reported, vehicle_reason):
    """当日判断(与 Excel 每日流水 L 列一致)。"""
    if vehicle_reason:
        return "车辆原因豁免"
    if (rest_reported and mode == "合作模式" and day_index is not None
            and day_index > 10):
        return "已报备休息"
    if target is None:
        return "无单日固定目标"
    return "达标" if amount >= target else "低于目标"


def _revenue_checkouts(db):
    return db.execute(
        """SELECT c.*, v.plate AS plate, d.name AS driver_name
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           ORDER BY CASE WHEN c.status='使用中' THEN 0 ELSE 1 END, d.name"""
        ).fetchall()


@app.route("/revenue")
@login_required
def revenue():
    db = get_db()
    today = date.today()
    month = request.args.get("month", today.strftime("%Y-%m"))
    try:
        y, m = int(month[:4]), int(month[5:7])
        first = date(y, m, 1)
    except (TypeError, ValueError):
        y, m = today.year, today.month
        month = today.strftime("%Y-%m")
        first = date(y, m, 1)
    last = date(y, m, monthrange(y, m)[1])
    co_id = parse_int(request.args.get("checkout_id"))
    base = """SELECT r.*, c.mode AS mode, c.contract_start AS contract_start,
                     c.deposit_total AS deposit_total,
                     c.deposit_paid AS deposit_paid,
                     v.plate AS plate, d.name AS driver_name, c.code AS code
              FROM daily_revenue r
              JOIN checkouts c ON c.id = r.checkout_id
              JOIN vehicles v ON v.id = c.vehicle_id
              JOIN drivers d ON d.id = c.driver_id
              WHERE r.revenue_date BETWEEN ? AND ?"""
    params = [first.isoformat(), last.isoformat()]
    if co_id:
        base += " AND r.checkout_id = ?"
        params.append(co_id)
    rows = db.execute(base + " ORDER BY r.revenue_date DESC, r.id DESC",
                      params).fetchall()
    items = []
    total_amt = 0.0
    for r in rows:
        rdate = parse_date(r["revenue_date"])
        day_index, target, near3, tip = revenue_day_info(db, r, rdate,
                                                         r["amount"])
        items.append({
            "r": r, "day_index": day_index, "target": target,
            "near3": near3, "tip": tip,
            "judge": revenue_judgement(r["mode"], day_index, target,
                                       r["amount"], r["rest_reported"],
                                       r["vehicle_reason"]),
        })
        total_amt += float(r["amount"])
    checkouts = _revenue_checkouts(db)
    prev_m = (first - timedelta(days=1)).strftime("%Y-%m")
    next_m = (last + timedelta(days=1)).strftime("%Y-%m")
    return render_template("revenue.html", items=items, month=month,
                           total_amt=total_amt, checkouts=checkouts,
                           co_id=co_id, prev_m=prev_m, next_m=next_m,
                           fmt_money=fmt_money)


@app.route("/revenue/new", methods=["GET", "POST"])
@login_required
def revenue_new():
    db = get_db()
    if request.method == "POST":
        co_id = parse_int(request.form.get("checkout_id"))
        rdate = request.form.get("revenue_date", "").strip()
        amount = parse_money(request.form.get("amount"))
        errors = []
        if not co_id:
            errors.append("要选一条出库。")
        if not rdate or parse_date(rdate) is None:
            errors.append("日期必填, 格式要对。")
        if amount is None:
            errors.append("有效流水必填, 金额不能是负数。")
        if co_id and db.execute("SELECT id FROM checkouts WHERE id = ?",
                                (co_id,)).fetchone() is None:
            errors.append("选的出库不存在。")
        if not errors and db.execute(
                "SELECT id FROM daily_revenue "
                "WHERE checkout_id=? AND revenue_date=?",
                (co_id, rdate)).fetchone():
            errors.append("这条出库这天已经录过流水了, 去列表里改那一条, 别重复录。")
        if errors:
            for e in errors:
                flash(e)
        else:
            db.execute(
                """INSERT INTO daily_revenue (checkout_id, revenue_date,
                     platform, amount, rest_reported, vehicle_reason, notes)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (co_id, rdate, request.form.get("platform") or None, amount,
                 1 if request.form.get("rest_reported") else 0,
                 1 if request.form.get("vehicle_reason") else 0,
                 request.form.get("notes", "").strip() or None))
            db.commit()
            flash("流水已记好。")
            return redirect(url_for("revenue", month=rdate[:7]))
        return render_template("revenue_form.html", r=None,
                               checkouts=_revenue_checkouts(db),
                               platforms=PLATFORMS,
                               default_date=rdate)
    return render_template("revenue_form.html", r=None,
                           checkouts=_revenue_checkouts(db),
                           platforms=PLATFORMS,
                           default_date=date.today().isoformat())


@app.route("/revenue/<int:rid>/edit", methods=["GET", "POST"])
@login_required
def revenue_edit(rid):
    db = get_db()
    r = db.execute("SELECT * FROM daily_revenue WHERE id = ?",
                   (rid,)).fetchone()
    if r is None:
        abort(404)
    if request.method == "POST":
        co_id = parse_int(request.form.get("checkout_id"))
        rdate = request.form.get("revenue_date", "").strip()
        amount = parse_money(request.form.get("amount"))
        errors = []
        if not co_id:
            errors.append("要选一条出库。")
        if not rdate or parse_date(rdate) is None:
            errors.append("日期必填, 格式要对。")
        if amount is None:
            errors.append("有效流水必填, 金额不能是负数。")
        if not errors and db.execute(
                "SELECT id FROM daily_revenue WHERE checkout_id=? "
                "AND revenue_date=? AND id != ?",
                (co_id, rdate, rid)).fetchone():
            errors.append("这条出库这天已经有另一条流水了, 不能改成重复的。")
        if errors:
            for e in errors:
                flash(e)
        else:
            db.execute(
                """UPDATE daily_revenue SET checkout_id=?, revenue_date=?,
                     platform=?, amount=?, rest_reported=?, vehicle_reason=?,
                     notes=? WHERE id=?""",
                (co_id, rdate, request.form.get("platform") or None, amount,
                 1 if request.form.get("rest_reported") else 0,
                 1 if request.form.get("vehicle_reason") else 0,
                 request.form.get("notes", "").strip() or None, rid))
            db.commit()
            flash("流水已改好。")
            return redirect(url_for("revenue", month=rdate[:7]))
    return render_template("revenue_form.html", r=r,
                           checkouts=_revenue_checkouts(db),
                           platforms=PLATFORMS,
                           default_date=r["revenue_date"])


@app.route("/revenue/<int:rid>/delete", methods=["POST"])
@admin_required
def revenue_delete(rid):
    db = get_db()
    r = db.execute("SELECT * FROM daily_revenue WHERE id = ?",
                   (rid,)).fetchone()
    if r is None:
        abort(404)
    db.execute("DELETE FROM daily_revenue WHERE id = ?", (rid,))
    db.commit()
    flash("这条流水已删除。")
    return redirect(url_for("revenue", month=r["revenue_date"][:7]))


# ---------- 月度结算 ----------
def coop_split(revenue):
    """合作阶梯分成(与 Excel 月度结算 G/H 列一致):
    流水<11000 公司 3500; <12000 公司 3000; 否则 2500。司机 = 流水 - 公司。
    注意: 流水<3500 时司机收益为负, Excel 原样显示并给复核提示, 这里不抹掉。"""
    if revenue < 11000:
        company = 3500.0
    elif revenue < 12000:
        company = 3000.0
    else:
        company = 2500.0
    return company, revenue - company


@app.route("/settlement")
@admin_required
def settlement():
    db = get_db()
    today = date.today()
    month = request.args.get("month", today.strftime("%Y-%m"))
    try:
        y, m = int(month[:4]), int(month[5:7])
        first = date(y, m, 1)
    except (TypeError, ValueError):
        y, m = today.year, today.month
        month = today.strftime("%Y-%m")
        first = date(y, m, 1)
    last = date(y, m, monthrange(y, m)[1])
    rows = db.execute(
        """SELECT c.*, v.plate AS plate, d.name AS driver_name,
                  v.monthly_payment AS monthly_payment
           FROM checkouts c
           JOIN vehicles v ON v.id = c.vehicle_id
           JOIN drivers d ON d.id = c.driver_id
           ORDER BY c.mode, d.name""").fetchall()
    items = []
    coop_company_total = coop_driver_total = rent_theory_total = 0.0
    upstream_total = 0.0
    missing_payment = []
    dim = (last - first).days + 1
    for co in rows:
        start = parse_date(co["contract_start"])
        end = contract_end_of(co)
        ret = parse_date(co["return_date"])
        if start is None or start > last:
            continue
        if end is not None and end < first:
            continue
        if ret is not None and ret < first:
            continue
        # 当月在跑天数: 纯租理论租金与上游月供折算共用
        upper = last
        if ret is not None:
            upper = min(upper, ret)
        lower = max(first, start)
        days = max(0, (upper - lower).days + 1)
        # 上游月供按天折算进成本; 没填月供的车不计成本, 另行提醒补填
        mp = co["monthly_payment"]
        if mp is None:
            missing_payment.append(co)
        else:
            upstream_total += float(mp) * days / dim
        if co["mode"] == "合作模式":
            rev = float(db.execute(
                "SELECT COALESCE(SUM(amount),0) FROM daily_revenue "
                "WHERE checkout_id=? AND revenue_date BETWEEN ? AND ?",
                (co["id"], first.isoformat(),
                 last.isoformat())).fetchone()[0])
            company, driver = coop_split(rev)
            fee = co["service_fee"] or 0
            settle = driver - fee
            if rev < 3500:
                warn = "流水低于3500：按合同月度公式会出现司机收益为负，需结合提前退出条款人工复核"
            else:
                warn = "合作分成未扣退款/事故/违章等待定费用"
            coop_company_total += company
            coop_driver_total += driver
            items.append({"co": co, "mode": "合作模式", "revenue": rev,
                          "company": company, "driver": driver, "fee": fee,
                          "settle": settle, "warn": warn})
        else:
            daily = (float(co["monthly_rent"]) / 30
                     if co["monthly_rent"] is not None else None)
            theory = days * daily if daily is not None else None
            if theory is not None:
                rent_theory_total += theory
            items.append({"co": co, "mode": "纯租", "days": days,
                          "daily": daily, "theory": theory,
                          "settle": theory,
                          "warn": "纯租理论租金；保证金、违约金、超里程等另核"})
    # 毛利 = 总收入(纯租理论租金 + 合作公司分成) − 上游月供(按天折算)。
    # 维修保养不在系统里, 所以只能算毛利, 不是净利润。
    gross_profit = rent_theory_total + coop_company_total - upstream_total
    prev_m = (first - timedelta(days=1)).strftime("%Y-%m")
    next_m = (last + timedelta(days=1)).strftime("%Y-%m")
    return render_template("settlement.html", items=items, month=month,
                           prev_m=prev_m, next_m=next_m,
                           coop_company_total=coop_company_total,
                           coop_driver_total=coop_driver_total,
                           rent_theory_total=rent_theory_total,
                           gross_profit=gross_profit,
                           upstream_total=upstream_total,
                           missing_payment=missing_payment,
                           fmt_money=fmt_money)


# ---------- 销售版块(意向司机池) ----------
@app.route("/sales")
@login_required
def sales():
    db = get_db()
    today = date.today()
    status = request.args.get("status", "跟进中")
    if status not in ("全部", "跟进中", "已签约", "已流失"):
        status = "跟进中"
    show = request.args.get("show", "全部")
    if show not in ("全部", "expiring", "noexpiry", "revisit"):
        show = "全部"
    rows = db.execute("SELECT * FROM prospects ORDER BY id DESC").fetchall()
    status_counts = {"全部": len(rows), "跟进中": 0, "已签约": 0, "已流失": 0}
    for p in rows:
        if p["status"] in status_counts:
            status_counts[p["status"]] += 1
    items = []
    for p in rows:
        exp = parse_date(p["expiry_date"])
        days_left = (exp - today).days if exp is not None else None
        ref = parse_date(p["last_followup_date"]) or parse_date(p["created_at"])
        days_since = (today - ref).days if ref is not None else None
        items.append({"p": p, "days_left": days_left,
                      "days_since": days_since})
    if status != "全部":
        items = [it for it in items if it["p"]["status"] == status]
    if show == "expiring":
        items = [it for it in items
                 if it["days_left"] is not None and it["days_left"] <= 7]
    elif show == "noexpiry":
        items = [it for it in items if it["days_left"] is None]
    elif show == "revisit":
        items = [it for it in items
                 if it["days_left"] is None and it["days_since"] is not None
                 and it["days_since"] > 10]
    return render_template("sales.html", items=items, status=status,
                           show=show, status_counts=status_counts,
                           total=len(items))


def _sales_users(db):
    return db.execute(
        "SELECT username FROM users WHERE role='sales' ORDER BY id").fetchall()


@app.route("/sales/new", methods=["GET", "POST"])
@login_required
def sales_new():
    db = get_db()
    sales_users = _sales_users(db)
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        expiry = request.form.get("expiry_date") or None
        if not name:
            flash("姓名是必填的。")
            return render_template("sales_form.html", p=None,
                                   sales_users=sales_users,
                                   levels=INTENT_LEVELS,
                                   statuses=PROSPECT_STATUS)
        if expiry and parse_date(expiry) is None:
            flash("到期日格式不对。")
            return render_template("sales_form.html", p=None,
                                   sales_users=sales_users,
                                   levels=INTENT_LEVELS,
                                   statuses=PROSPECT_STATUS)
        today_s = date.today().isoformat()
        db.execute(
            """INSERT INTO prospects (code, name, phone, wechat_name,
                 current_company, expiry_date, intent_level, owner, last_chat,
                 status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (next_code("prospects", "YX"), name,
             request.form.get("phone", "").strip() or None,
             request.form.get("wechat_name", "").strip() or None,
             request.form.get("current_company", "").strip() or None,
             expiry,
             request.form.get("intent_level") or None,
             request.form.get("owner", "").strip() or None,
             request.form.get("last_chat", "").strip() or None,
             "跟进中", today_s, today_s))
        db.commit()
        flash(f"意向司机 {name} 已加上。")
        return redirect(url_for("sales"))
    return render_template("sales_form.html", p=None,
                           sales_users=sales_users,
                           levels=INTENT_LEVELS,
                           statuses=PROSPECT_STATUS)


@app.route("/sales/<int:pid>")
@login_required
def sales_detail(pid):
    db = get_db()
    today = date.today()
    p = db.execute("SELECT * FROM prospects WHERE id = ?",
                   (pid,)).fetchone()
    if p is None:
        abort(404)
    followups = db.execute(
        "SELECT * FROM prospect_followups WHERE prospect_id = ? "
        "ORDER BY followup_date DESC, id DESC", (pid,)).fetchall()
    exp = parse_date(p["expiry_date"])
    days_left = (exp - today).days if exp is not None else None
    ref = parse_date(p["last_followup_date"]) or parse_date(p["created_at"])
    days_since = (today - ref).days if ref is not None else None
    return render_template("sales_detail.html", p=p, followups=followups,
                           days_left=days_left, days_since=days_since,
                           today=today.isoformat())


@app.route("/sales/<int:pid>/edit", methods=["GET", "POST"])
@login_required
def sales_edit(pid):
    db = get_db()
    p = db.execute("SELECT * FROM prospects WHERE id = ?", (pid,)).fetchone()
    if p is None:
        abort(404)
    sales_users = _sales_users(db)
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        status = request.form.get("status", "跟进中")
        if status not in PROSPECT_STATUS:
            status = "跟进中"
        expiry = request.form.get("expiry_date") or None
        if not name:
            flash("姓名是必填的。")
            return render_template("sales_form.html", p=p,
                                   sales_users=sales_users,
                                   levels=INTENT_LEVELS,
                                   statuses=PROSPECT_STATUS)
        if expiry and parse_date(expiry) is None:
            flash("到期日格式不对。")
            return render_template("sales_form.html", p=p,
                                   sales_users=sales_users,
                                   levels=INTENT_LEVELS,
                                   statuses=PROSPECT_STATUS)
        db.execute(
            """UPDATE prospects SET name=?, phone=?, wechat_name=?,
                 current_company=?, expiry_date=?, intent_level=?, owner=?,
                 last_chat=?, status=?, updated_at=? WHERE id=?""",
            (name,
             request.form.get("phone", "").strip() or None,
             request.form.get("wechat_name", "").strip() or None,
             request.form.get("current_company", "").strip() or None,
             expiry,
             request.form.get("intent_level") or None,
             request.form.get("owner", "").strip() or None,
             request.form.get("last_chat", "").strip() or None,
             status, date.today().isoformat(), pid))
        db.commit()
        flash(f"意向司机 {name} 已改好。")
        return redirect(url_for("sales_detail", pid=pid))
    return render_template("sales_form.html", p=p,
                           sales_users=sales_users,
                           levels=INTENT_LEVELS,
                           statuses=PROSPECT_STATUS)


@app.route("/sales/<int:pid>/followup", methods=["POST"])
@login_required
def sales_followup(pid):
    db = get_db()
    p = db.execute("SELECT * FROM prospects WHERE id = ?", (pid,)).fetchone()
    if p is None:
        abort(404)
    fdate = request.form.get("followup_date", "").strip() or date.today().isoformat()
    content = request.form.get("content", "").strip()
    if parse_date(fdate) is None:
        flash("跟进日期格式不对。")
        return redirect(url_for("sales_detail", pid=pid))
    if not content:
        flash("跟进内容要写一句。")
        return redirect(url_for("sales_detail", pid=pid))
    db.execute(
        "INSERT INTO prospect_followups "
        "(prospect_id, followup_date, content, created_by) VALUES (?, ?, ?, ?)",
        (pid, fdate, content, session.get("username")))
    db.execute("UPDATE prospects SET last_followup_date=?, updated_at=? "
               "WHERE id=?",
               (fdate, date.today().isoformat(), pid))
    db.commit()
    flash("跟进记录已加上。")
    return redirect(url_for("sales_detail", pid=pid))


@app.route("/sales/<int:pid>/delete", methods=["POST"])
@admin_required
def sales_delete(pid):
    db = get_db()
    p = db.execute("SELECT * FROM prospects WHERE id = ?", (pid,)).fetchone()
    if p is None:
        abort(404)
    db.execute("DELETE FROM prospect_followups WHERE prospect_id = ?", (pid,))
    db.execute("DELETE FROM prospects WHERE id = ?", (pid,))
    db.commit()
    flash(f"意向司机 {p['name']} 已删除。")
    return redirect(url_for("sales"))


# 启动时建表/迁移: 必须放在模块顶层, 不能只放在 __main__ 里,
# 否则用 flask run / gunicorn 启动时 init_db() 不执行, daily_revenue 表不存在,
# 每日流水页会 500。init_db() 本身是幂等的, 重复调用无害。
init_db()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
